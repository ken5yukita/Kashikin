import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  applyAnswer,
  isCycleComplete,
  mastery,
  overallStats,
  scoreSession,
  selectQuestions,
  selectToday,
  searchQuestions,
  startOfDay,
} from '../src/lib/logic.ts';
import { validateQuestion } from '../src/lib/validate.ts';
import type { Progress, Question, Session } from '../src/types.ts';
import { readFileSync } from 'node:fs';

function seeded(seed: number) {
  return () => {
    seed = (seed * 1664525 + 1013904223) % 2 ** 32;
    return seed / 2 ** 32;
  };
}

function mk(i: number, cat: Question['category'] = '貸金業法', choicesSig?: string): Question {
  const s = choicesSig ?? `q${i}`;
  return {
    id: `t-q${String(i).padStart(3, '0')}`,
    examId: 't',
    examName: 't',
    questionNumber: i,
    category: cat,
    questionText: `問題${i}`,
    choices: [1, 2, 3, 4].map((n) => ({ id: n as 1, text: `${s}-${n}` })),
    correctAnswer: 2,
    sourceType: 'original',
    source: 't',
    verified: true,
  };
}

const DAY = 86400000;
const NOW = new Date('2026-10-14T10:00:00+09:00').getTime();

test('同一セッション内で問題IDが重複しない（入力に重複があっても）', () => {
  const pool = Array.from({ length: 30 }, (_, i) => mk(i));
  const withDup = [...pool, ...pool, pool[0]];
  for (let s = 1; s < 200; s++) {
    const out = selectQuestions(withDup, 30, { progress: new Map(), cycle: 1, now: NOW, rng: seeded(s) });
    assert.equal(out.length, 30);
    assert.equal(new Set(out.map((q) => q.id)).size, 30);
  }
});

test('要求数が母数より多い場合は母数分だけ（重複で埋めない）', () => {
  const pool = Array.from({ length: 7 }, (_, i) => mk(i));
  const out = selectQuestions(pool, 10, { progress: new Map(), cycle: 1, now: NOW });
  assert.equal(out.length, 7);
});

test('同一選択肢セットは可能な限り避ける', () => {
  const pool = [mk(1, '民法', 'same'), mk(2, '民法', 'same'), mk(3), mk(4), mk(5)];
  for (let s = 1; s < 50; s++) {
    const out = selectQuestions(pool, 4, { progress: new Map(), cycle: 1, now: NOW, rng: seeded(s) });
    const sameCount = out.filter((q) => q.choices[0].text.startsWith('same')).length;
    assert.equal(sameCount, 1);
  }
  // 足りないときは許容（ただしID重複はなし）
  const out = selectQuestions(pool, 5, { progress: new Map(), cycle: 1, now: NOW });
  assert.equal(new Set(out.map((q) => q.id)).size, 5);
});

test('未出題（未回答）問題を優先し、全問1周するまで既出問題を出さない', () => {
  const pool = Array.from({ length: 100 }, (_, i) => mk(i));
  const progress = new Map<string, Progress>();
  const seen = new Set<string>();
  for (let round = 0; round < 10; round++) {
    const out = selectQuestions(pool, 10, { progress, cycle: 1, now: NOW + round, rng: seeded(round + 1) });
    for (const q of out) {
      assert.ok(!seen.has(q.id), `1周目で再出題された: ${q.id}`);
      seen.add(q.id);
      progress.set(q.id, applyAnswer(progress.get(q.id), q.id, 1, false, NOW + round, 1));
    }
  }
  assert.equal(seen.size, 100);
  assert.ok(isCycleComplete(pool, progress, 1));
});

test('出題済みの中では間違えた問題・古い問題が優先される', () => {
  const pool = [mk(1), mk(2), mk(3)];
  const progress = new Map<string, Progress>();
  progress.set(pool[0].id, applyAnswer(undefined, pool[0].id, 2, true, NOW - 1 * DAY, 1));
  progress.set(pool[1].id, applyAnswer(undefined, pool[1].id, 1, false, NOW - 1 * DAY, 1));
  progress.set(pool[2].id, applyAnswer(undefined, pool[2].id, 2, true, NOW - 30 * DAY, 1));
  const out = selectQuestions(pool, 3, { progress, cycle: 1, now: NOW, rng: seeded(3) });
  assert.equal(out[0].id, pool[1].id); // 間違えた（+3）
});

test('過去問別（keep）は本番の順番どおり', () => {
  const pool = Array.from({ length: 50 }, (_, i) => mk(i + 1));
  const out = selectQuestions(pool, 50, { progress: new Map(), cycle: 1, now: NOW }, 'keep');
  assert.deepEqual(out.map((q) => q.questionNumber), pool.map((q) => q.questionNumber));
});

test('回答記録：初回・直近・連続正誤・間隔反復', () => {
  let p = applyAnswer(undefined, 'x', 1, false, NOW, 1);
  assert.equal(p.firstCorrect, false);
  assert.equal(p.dueAt, NOW);
  assert.equal(mastery(p), 'review');
  p = applyAnswer(p, 'x', 3, false, NOW + 1, 1);
  assert.equal(p.consecutiveWrong, 2);
  assert.equal(mastery(p), 'weak');
  p = applyAnswer(p, 'x', 2, true, NOW + 2, 1);
  assert.equal(p.firstAnswer, 1);
  assert.equal(p.lastAnswer, 2);
  assert.equal(p.dueAt, startOfDay(NOW) + 1 * DAY);
  p = applyAnswer(p, 'x', 2, true, NOW + 3, 1);
  assert.equal(p.dueAt, startOfDay(NOW) + 3 * DAY);
  p = applyAnswer(p, 'x', 2, true, NOW + 4, 1);
  assert.equal(mastery(p), 'mastered');
  const first = applyAnswer(undefined, 'y', 2, true, NOW, 1);
  assert.equal(first.dueAt, null);
  assert.equal(mastery(first), 'mastered');
});

test('今日の学習：復習期限の問題が先頭、今日正解済みは除外', () => {
  const pool = Array.from({ length: 10 }, (_, i) => mk(i));
  const progress = new Map<string, Progress>();
  progress.set(pool[5].id, applyAnswer(undefined, pool[5].id, 1, false, NOW - 2 * DAY, 1));
  progress.set(pool[6].id, applyAnswer(undefined, pool[6].id, 2, true, NOW - 1000, 1));
  const out = selectToday(pool, 5, { progress, cycle: 1, now: NOW, rng: seeded(9) });
  assert.equal(out[0].id, pool[5].id);
  assert.ok(!out.some((q) => q.id === pool[6].id));
  assert.equal(new Set(out.map((q) => q.id)).size, out.length);
});

test('採点と合否（score >= passingScore）', () => {
  const qs = Array.from({ length: 50 }, (_, i) => mk(i, i < 25 ? '貸金業法' : '民法'));
  const answers: Session['answers'] = {};
  qs.forEach((q, i) => (answers[q.id] = i < 31 ? 2 : 1));
  const session = { questionIds: [...qs.map((q) => q.id), 'deleted-id'], answers, passingScore: 31 } as Session;
  const r = scoreSession(session, new Map(qs.map((q) => [q.id, q])), NOW);
  assert.equal(r.total, 50); // 削除済みIDは無視してクラッシュしない
  assert.equal(r.correct, 31);
  assert.equal(r.passed, true);
  assert.equal(scoreSession({ ...session, passingScore: 32 }, new Map(qs.map((q) => [q.id, q])), NOW).passed, false);
  assert.equal(r.byCategory.find((c) => c.category === '民法')!.correct, 6);
});

test('統計：連続学習日数・今日・今週', () => {
  const logs = [0, 1, 2, 5].map((d, i) => ({
    questionId: 'x' + i, selected: 1 as const, correct: i % 2 === 0, answeredAt: NOW - d * DAY, sessionId: 's', mode: 'random' as const, category: '民法' as const,
  }));
  const s = overallStats(logs, NOW);
  assert.equal(s.streak, 3);
  assert.equal(s.today, 1);
  assert.equal(s.week, 4);
  assert.equal(s.totalAnswers, 4);
});

test('検索：全角半角・スペースAND', () => {
  const q = { ...mk(1), questionText: '総量規制に関する問題（年収の３分の１）' };
  const qs = [q, mk(2)];
  assert.equal(searchQuestions(qs, new Map(), '総量規制').length, 1);
  assert.equal(searchQuestions(qs, new Map(), '総量規制 3分の1').length, 1);
  assert.equal(searchQuestions(qs, new Map(), '総量規制 民法').length, 0);
});

test('同梱オリジナル例題はすべて検証を通り、引用が本文と一致する', () => {
  const data = JSON.parse(readFileSync(new URL('../public/data/questions/original.json', import.meta.url), 'utf8'));
  const ids = new Set<string>();
  for (const q of data.questions) {
    const r = validateQuestion(q);
    assert.deepEqual(r.errors, [], q.id);
    assert.deepEqual(r.warnings, [], q.id);
    assert.ok(!ids.has(q.id));
    ids.add(q.id);
    assert.equal(q.sourceType, 'original');
    // 正答肢の解説は「適切」かつ問題文の指示（適切なものを選ぶ）と整合
    const ce = q.explanation.choices.find((c: { id: number }) => c.id === q.correctAnswer);
    assert.equal(ce.verdict, 'appropriate', q.id);
  }
});

test('検証：壊れた問題を検出', () => {
  assert.equal(validateQuestion({ id: 'a' }).ok, false);
  const bad = { ...mk(1), correctAnswer: 5 };
  assert.ok(validateQuestion(bad).errors.some((e) => e.includes('correctAnswer')));
  const three = { ...mk(1), choices: mk(1).choices.slice(0, 3) };
  assert.ok(validateQuestion(three).errors.some((e) => e.includes('4つ')));
});
