import { test } from 'node:test';
import assert from 'node:assert/strict';
import { detectKind, parseAnswerKey, parsePaper, tidySpaces } from '../src/lib/pdfParse.ts';
import { guessRound } from '../src/data/exams.ts';

// 実際の問題用紙の「レイアウト」を模した合成テキスト（文言はダミー）
const cover = {
  page: 1,
  lines: ['DKIH-01.smd  Page 1 17/10/23 16:43  v3.40', '平成 29 年度', '貸金業務取扱主任者資格試験問題用紙', '（注意事項）', '① 試験時間は2時間です。'],
};
const p2 = {
  page: 2,
  lines: [
    'DKIH-01.smd  Page 2 17/10/23 16:43  v3.40',
    '【問題 1】',
    'ダミー法に関する次の①〜④の記述のうち、その内容が適切なものを1つだけ選び、解答欄にその',
    '番号をマークしなさい。',
    '① ダミー事業者は、営業所ごとに 50 分の 1 以上の割合で',
    '担当者を置かなければならない。',
    '② ダミー事業者は、届出をすることができる。',
    '③ ダミー事業者は、届出をすることができない。',
    '④ ダミー事業者は、2 週間以内に届け出なければならない。',
    '−1−',
    '【問題 �】',
    'ダミー法に関する次のａ〜ｄの記述のうち、その内容が適切なものの組み合わせを',
    '①〜④の中から1つだけ選びなさい。',
    'ａ 記述Ａの本文で、行が',
    '折り返されている。',
    'ｂ 記述Ｂの本文。',
    'ｃ 記述Ｃの本文で � 日以内とする。',
    'ｄ 記述Ｄの本文。',
    '① ａｂ ② ａｃ ③ ｂｄ ④ ｃｄ',
  ],
};
const p3 = {
  page: 3,
  lines: [
    '【問題 3】',
    '次の記述のうち、適切なものの個数を①〜④の中から1つだけ選びなさい。',
    'ア 記述アの本文。',
    'イ 記述イの本文。',
    'ウ 記述ウの本文。',
    'エ 記述エの本文。',
    '① 1個 ② 2個 ③ 3個 ④ 4個',
    '（注）本問における「ダミー」とは、テスト用の語をいう。',
    '−2−',
    '【問題 4】',
    '選択肢が3つしかない壊れた問題。',
    '① A',
    '② B',
    '③ C',
    '（以 上）',
  ],
};

test('問題用紙：ヘッダー・ページ番号除去、選択肢分離、改行結合', () => {
  const { questions, warnings } = parsePaper([cover, p2, p3]);
  assert.equal(questions.length, 4);
  assert.ok(warnings.some((w) => w.includes('4問')));
  const q1 = questions[0];
  assert.equal(q1.markerNumber, 1);
  assert.equal(
    q1.questionText,
    'ダミー法に関する次の①〜④の記述のうち、その内容が適切なものを1つだけ選び、解答欄にその番号をマークしなさい。',
  );
  assert.equal(q1.choices[0].text, 'ダミー事業者は、営業所ごとに50分の1以上の割合で担当者を置かなければならない。');
  // 「できる」「できない」は改変しない
  assert.equal(q1.choices[1].text, 'ダミー事業者は、届出をすることができる。');
  assert.equal(q1.choices[2].text, 'ダミー事業者は、届出をすることができない。');
  assert.equal(q1.choices[3].text, 'ダミー事業者は、2週間以内に届け出なければならない。');
  assert.deepEqual(q1.issues, []);
  assert.deepEqual(q1.pages, [2]);
});

test('組合せ問題：小問ａ〜ｄ、1行に並んだ選択肢、判読不能文字の検出', () => {
  const { questions } = parsePaper([cover, p2, p3]);
  const q2 = questions[1];
  assert.equal(q2.markerNumber, null);
  assert.equal(q2.seq, 2);
  // 行頭の「①〜④の中から」は選択肢と誤認しない
  assert.ok(q2.questionText.endsWith('①〜④の中から1つだけ選びなさい。'));
  assert.deepEqual(q2.items.map((i) => i.label), ['ａ', 'ｂ', 'ｃ', 'ｄ']);
  assert.equal(q2.items[0].text, '記述Ａの本文で、行が折り返されている。');
  assert.deepEqual(q2.choices.map((c) => c.text), ['ａｂ', 'ａｃ', 'ｂｄ', 'ｃｄ']);
  assert.ok(q2.issues.some((i) => i.includes('判読不能')));
  assert.ok(q2.issues.some((i) => i.includes('問題番号')));
});

test('個数問題（ア〜エ）と注釈の分離', () => {
  const { questions } = parsePaper([cover, p2, p3]);
  const q3 = questions[2];
  assert.deepEqual(q3.items.map((i) => i.label), ['ア', 'イ', 'ウ', 'エ']);
  assert.deepEqual(q3.choices.map((c) => c.text), ['1個', '2個', '3個', '4個']);
  assert.equal(q3.annotations.length, 1);
  assert.equal(q3.annotations[0].anchorText, null);
  assert.ok(!q3.choices[3].text.includes('注'));
});

test('選択肢不足は要確認として検出、「（以上）」は本文に混入しない', () => {
  const { questions } = parsePaper([cover, p2, p3]);
  const q4 = questions[3];
  assert.ok(q4.issues.some((i) => i.includes('3個')));
  assert.equal(q4.choices[2].text, 'C');
});

test('正答PDF：2段組みの「問題 n ②」を読み取る', () => {
  const lines: string[] = [];
  for (let i = 1; i <= 25; i++) lines.push(`問題 ${String(i).padStart(2, ' ')} ${'①②③④'[i % 4]} 問題 ${i + 25} ${'①②③④'[(i + 1) % 4]}`);
  const { answers, warnings } = parseAnswerKey('問題番号 正　答 問題番号 正　答\n' + lines.join('\n') + '\n令和７年度');
  assert.equal(answers.size, 50);
  assert.equal(answers.get(1), 2);
  assert.equal(answers.get(26), 3);
  assert.deepEqual(warnings, []);
  const partial = parseAnswerKey('問題 1 ①\n問題２ ③');
  assert.equal(partial.answers.get(2), 3);
  assert.ok(partial.warnings[0].includes('3'));
});

test('PDF種別と試験回の推定', () => {
  assert.equal(detectKind('20th_answer.pdf', ''), 'answer');
  assert.equal(detectKind('exam_paper_12th.pdf', ''), 'paper');
  assert.equal(detectKind('scan.pdf', '【問題 1】'), 'paper');
  assert.equal(guessRound('exam_paper_12th.pdf', ''), 12);
  assert.equal(guessRound('18th_answer.pdf', ''), 18);
  assert.equal(guessRound('exam_paper.pdf', ''), 1);
  assert.equal(guessRound('x.pdf', '令和 4年度\n貸金業務取扱主任者資格試験問題用紙'), 17);
  assert.equal(guessRound('x.pdf', '令和元年度'), 14);
  assert.equal(guessRound('x.pdf', '平成 21 年度（第�回）'), null); // 第1〜4回のいずれか判別不能
});

test('空白整理は CJK 隣接の半角空白のみ', () => {
  assert.equal(tidySpaces('貸金業法第 10 条の 2'), '貸金業法第10条の2');
  assert.equal(tidySpaces('Cornel Medical Index'), 'Cornel Medical Index');
});

test('判読不能な記号で囲まれたページ番号も除去、康熙部首は通常の漢字へ', async () => {
  const { isNoiseLine, normalizeRadicals } = await import('../src/lib/pdfParse.ts');
  assert.equal(isNoiseLine('\ue09e18\ue09e'), true);
  assert.equal(isNoiseLine('−�−'), true);
  assert.equal(isNoiseLine('1'), true);
  assert.equal(isNoiseLine('ａ 記述'), false);
  assert.equal(normalizeRadicals('書⾯を交付し、その⽇から'), '書面を交付し、その日から');
  // 全角英数字・丸数字は変えない
  assert.equal(normalizeRadicals('ａｂ①１'), 'ａｂ①１');
  const { questions } = parsePaper([{ page: 1, lines: ['【問題 1】', '問い。', '① あ', '② い', '③ う', '④ え', '\ue09e18\ue09e'] }]);
  assert.equal(questions[0].choices[3].text, 'え');
  assert.deepEqual(questions[0].issues, []);
});
