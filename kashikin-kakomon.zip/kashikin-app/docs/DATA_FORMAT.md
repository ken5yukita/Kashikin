# データ形式

問題データと学習データは別管理。UIの変更なしに、JSONの追加だけで問題・解説を増やせる構成。

## 1. 問題データ（Question）

| 項目 | 型 | 必須 | 内容 |
|---|---|---|---|
| id | string | ○ | 一意のID。公式過去問は `exam{回2桁}-q{問3桁}`（例 `exam12-q005`） |
| examId | string | ○ | `exam01`〜`exam20`、オリジナルは `original` |
| examName | string | ○ | 試験回名 |
| questionNumber | number | ○ | 問題番号 |
| category | string | ○ | 分野（下記11分類のいずれか） |
| subcategory | string |  | 小分類（例：総量規制）。同じ小分類の問題を関連問題として表示 |
| questionText | string | ○ | 問題文（原文どおり。改変禁止） |
| items | {label,text}[] |  | 組合せ・個数問題の小問（ａ〜ｄ、ア〜エ） |
| choices | {id,text}[] | ○ | 選択肢4つ。id は 1〜4 |
| correctAnswer | 1〜4 | ○ | 正答番号。正誤判定はこの値のみで行う |
| annotations | {text,anchorText}[] |  | 注釈。位置不明なら anchorText は null（本文に挿入しない） |
| explanation | Explanation |  | 解説（下記） |
| legalBasis | string[] |  | 法律上の根拠（条文番号は確認済みのもののみ） |
| relatedQuestionIds | string[] |  | 関連問題のID |
| sourceType | `official` / `original` / `user` | ○ | 公式問題とオリジナルの区別 |
| source | string | ○ | 出典 |
| verified | boolean | ○ | 原本と照合済みか。false は模試から除外（設定で変更可） |

分野：貸金業法／利息制限法／出資法／民法／商法／民事手続／個人情報保護／犯罪収益移転防止法／財務・会計／資金需要者保護／その他関連法令

起動時の検証：id・questionText・choices 4つ・correctAnswer 1〜4・category 等。不備のある問題はその問題だけ除外し、アプリは停止しない（設定 → 問題データ情報 に一覧表示）。

## 2. 解説（Explanation）

```json
{
  "summary": "この問題で問われている論点の要約",
  "choices": [
    {
      "id": 1,
      "verdict": "inappropriate",
      "wrongQuote": "選択肢①の本文から正確に抜き出した誤り箇所",
      "correctContent": "正しい内容",
      "reason": "なぜ誤りか（この問題に即した説明）"
    },
    { "id": 2, "verdict": "appropriate", "reason": "なぜ正しいか" }
  ],
  "items": [
    { "label": "ａ", "verdict": "appropriate", "reason": "…" }
  ],
  "trapPoints": ["「以上」ではなく「超える」である点に注意"],
  "memoryPoints": ["○○は△△％"]
}
```

- `verdict` は「記述の内容が適切か」。正答肢かどうかとは別（「適切でないものを選べ」の正答肢は `inappropriate`）
- `wrongQuote` は問題文・小問・選択肢の文字列に含まれている必要あり。一致しない場合、画面に「引用が問題文と一致しません」と表示
- `choices` は4件そろえる（欠けると検証で警告）

## 3. 取込用JSON

設定 → データの取込（または ホーム → データの取込）の「ファイルを選ぶ」から読み込み。

**問題の追加・置換**
```json
{ "questions": [ { "id": "exam12-q001", "...": "..." } ] }
```

**既存問題への解説の追加**（問題文は変更しない）
```json
{
  "explanations": [
    {
      "questionId": "exam12-q001",
      "subcategory": "総量規制",
      "explanation": { "summary": "…", "choices": [ … ] },
      "legalBasis": ["貸金業法第13条の2第2項"],
      "relatedQuestionIds": ["exam10-q003"]
    }
  ]
}
```

`docs/explanation-template.json` に雛形あり。

## 4. 同梱データの追加

`public/data/questions/` にJSONを置き、`public/data/index.json` の `files` に1行追加。各ファイルの `version` を変えると、次回起動時に端末内データへ反映。

```json
{ "version": "2026-10-14.1", "questions": [ … ] }
```

## 5. 学習データ（端末内 IndexedDB）

| ストア | 内容 |
|---|---|
| progress | 問題ごとの回答回数・正解数・不正解数・連続正誤・初回回答・直近回答・最終不正解日時・復習期限 |
| answers | 回答ログ（問題ID・選択・正誤・日時・モード・分野） |
| bookmarks | ブックマーク |
| sessions | 出題セッション（確定した出題順・回答・現在位置・開始/終了・制限時間・結果） |
| kv | 設定・周回情報・同梱データ版数 |

バックアップJSON（設定 → 学習データをバックアップ）は上記のみを含み、問題データは含まない。問題IDで紐付けるため、問題を更新・削除しても履歴は壊れない。
