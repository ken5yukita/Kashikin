/**
 * ビルド：esbuild で src を束ね、dist/ に配置可能な PWA を出力する。
 *   node scripts/build.mjs          … 本番ビルド
 *   node scripts/build.mjs --serve  … ビルド後 http://localhost:5173 で配信（確認用）
 */
import { build } from 'esbuild';
import { createHash } from 'node:crypto';
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { dirname, extname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const dist = join(root, 'dist');
const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
const version = `${pkg.version}+${new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '')}`;

rmSync(dist, { recursive: true, force: true });
mkdirSync(dist, { recursive: true });

// 1) アプリ本体
const result = await build({
  entryPoints: [join(root, 'src/main.tsx')],
  bundle: true,
  splitting: true,
  format: 'esm',
  outdir: join(dist, 'assets'),
  entryNames: 'app-[hash]',
  chunkNames: 'chunk-[hash]',
  assetNames: '[name]-[hash]',
  minify: true,
  sourcemap: false,
  target: ['safari16', 'es2022'],
  jsx: 'automatic',
  define: { 'process.env.NODE_ENV': '"production"', __APP_VERSION__: JSON.stringify(version) },
  metafile: true,
  legalComments: 'none',
  logLevel: 'warning',
});

const outputs = Object.keys(result.metafile.outputs).map((p) => relative(dist, join(root, p)).replaceAll('\\', '/'));
const entryJs = outputs.find((p) => /assets\/app-.*\.js$/.test(p));
const entryCss = outputs.find((p) => /assets\/app-.*\.css$/.test(p));

// 2) index.html
let html = readFileSync(join(root, 'index.html'), 'utf8');
html = html.replace('<!--CSS-->', entryCss ? `<link rel="stylesheet" href="${entryCss}" />` : '');
html = html.replace('<!--JS-->', `<script type="module" src="${entryJs}"></script>`);
writeFileSync(join(dist, 'index.html'), html);

// 3) 静的ファイル（manifest・アイコン・問題データ）
cpSync(join(root, 'public'), dist, { recursive: true });

// 4) pdf.js のワーカー・CMap（日本語PDFの読み取りに必要）・標準フォント
const pdfjs = join(root, 'node_modules/pdfjs-dist');
mkdirSync(join(dist, 'pdfjs'), { recursive: true });
cpSync(join(pdfjs, 'legacy/build/pdf.worker.min.mjs'), join(dist, 'pdfjs/pdf.worker.min.mjs'));
cpSync(join(pdfjs, 'cmaps'), join(dist, 'pdfjs/cmaps'), { recursive: true });
cpSync(join(pdfjs, 'standard_fonts'), join(dist, 'pdfjs/standard_fonts'), { recursive: true });
for (const lic of ['LICENSE']) if (existsSync(join(pdfjs, lic))) cpSync(join(pdfjs, lic), join(dist, 'pdfjs/LICENSE.txt'));

// 5) Service Worker（全ファイルを事前キャッシュしてオフライン動作）
function walk(dir) {
  return readdirSync(dir).flatMap((f) => {
    const p = join(dir, f);
    return statSync(p).isDirectory() ? walk(p) : [p];
  });
}
const files = walk(dist)
  .map((p) => relative(dist, p).replaceAll('\\', '/'))
  .filter((p) => p !== 'sw.js' && !p.endsWith('.map') && !p.endsWith('LICENSE.txt'));
const hash = createHash('sha256');
for (const f of files.sort()) hash.update(f).update(readFileSync(join(dist, f)));
const cacheId = hash.digest('hex').slice(0, 12);
const sw = readFileSync(join(root, 'src/sw.js'), 'utf8')
  .replace('__CACHE_ID__', cacheId)
  .replace('__PRECACHE__', JSON.stringify(['./', ...files]));
writeFileSync(join(dist, 'sw.js'), sw);

const size = files.reduce((s, f) => s + statSync(join(dist, f)).size, 0);
console.log(`built ${version}  files=${files.length}  total=${(size / 1024 / 1024).toFixed(2)}MB  cache=${cacheId}`);
for (const o of outputs) console.log('  ', o, `${(statSync(join(dist, o)).size / 1024).toFixed(0)}KB`);

// --serve：確認用の簡易サーバー
if (process.argv.includes('--serve')) {
  const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.bcmap': 'application/octet-stream', '.pfb': 'application/octet-stream', '.ttf': 'font/ttf', '.pdf': 'application/pdf' };
  const port = Number(process.env.PORT || 5173);
  createServer((req, res) => {
    let p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
    if (p.endsWith('/')) p += 'index.html';
    const file = join(dist, p);
    if (!file.startsWith(dist) || !existsSync(file)) {
      res.writeHead(404).end('not found');
      return;
    }
    res.writeHead(200, { 'content-type': types[extname(file)] ?? 'application/octet-stream' });
    res.end(readFileSync(file));
  }).listen(port, () => console.log(`serving dist on http://localhost:${port}`));
}
