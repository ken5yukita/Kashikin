import type { ExamInfo } from '../types';

/**
 * 試験回マスタ
 * - 試験日：第1〜17回は日本貸金業協会「試験問題・過去問題等」ページの記載、
 *   第18〜20回は同協会「試験の結果」公表内容（二次情報で照合）。
 * - 合格基準点：日本貸金業協会「試験の結果について」公表値（二次情報で照合、2026年10月時点）。
 * - 合否判定：本試験は総得点（50問中の正解数）が合格基準点以上で合格。科目別の足切りはなし。
 *   新しい回を追加する場合、公表値が確認できるまで passingScore は null のままにする。
 */
const OFFICIAL_PAGE = 'https://www.j-fsa.or.jp/chief/qualifying_exam/exam_example/';
const SCORE_SOURCE = '日本貸金業協会「試験の結果について」公表値（2026年10月照合）';

const rows: Array<[number, string, string, number | null]> = [
  [1, '平成21年度', '2009-08-30', 30],
  [2, '平成21年度', '2009-11-22', 30],
  [3, '平成21年度', '2009-12-20', 33],
  [4, '平成21年度', '2010-02-28', 31],
  [5, '平成22年度', '2010-11-21', 30],
  [6, '平成23年度', '2011-11-20', 27],
  [7, '平成24年度', '2012-11-18', 29],
  [8, '平成25年度', '2013-11-17', 30],
  [9, '平成26年度', '2014-11-16', 30],
  [10, '平成27年度', '2015-11-15', 31],
  [11, '平成28年度', '2016-11-20', 30],
  [12, '平成29年度', '2017-11-19', 34],
  [13, '平成30年度', '2018-11-18', 32],
  [14, '令和元年度', '2019-11-17', 29],
  [15, '令和2年度', '2020-11-15', 33],
  [16, '令和3年度', '2021-11-21', 31],
  [17, '令和4年度', '2022-11-20', 28],
  [18, '令和5年度', '2023-11-19', 31],
  [19, '令和6年度', '2024-11-17', 30],
  [20, '令和7年度', '2025-11-16', 31],
];

export const pad2 = (n: number) => String(n).padStart(2, '0');

export const OFFICIAL_EXAMS: ExamInfo[] = rows.map(([round, nendo, date, score]) => ({
  examId: `exam${pad2(round)}`,
  examName: `第${round}回 貸金業務取扱主任者資格試験（${nendo}）`,
  round,
  examDate: date,
  questionCount: 50,
  passingScore: score,
  passingScoreSource: SCORE_SOURCE,
  source: OFFICIAL_PAGE,
}));

export const ORIGINAL_EXAM: ExamInfo = {
  examId: 'original',
  examName: 'オリジナル例題（公式問題ではありません）',
  round: null,
  examDate: '',
  questionCount: 0,
  passingScore: null,
  passingScoreSource: '',
  source: '本アプリ同梱のオリジナル問題',
};

export const OFFICIAL_PAGE_URL = OFFICIAL_PAGE;

export function getExam(examId: string): ExamInfo | undefined {
  if (examId === ORIGINAL_EXAM.examId) return ORIGINAL_EXAM;
  return OFFICIAL_EXAMS.find((e) => e.examId === examId);
}

/** ランダム模試の参考合格基準：収録済み直近回の基準点 */
export function referencePassingScore(): { score: number; label: string } {
  const latest = [...OFFICIAL_EXAMS].reverse().find((e) => e.passingScore != null)!;
  return { score: latest.passingScore!, label: `参考：第${latest.round}回の基準点` };
}

/** 年度表記・第N回表記・ファイル名から試験回を推定（確定ではなく候補） */
export function guessRound(fileName: string, text: string): number | null {
  const f = fileName.toLowerCase();
  const m = f.match(/(\d{1,2})(st|nd|rd|th)/);
  if (m) return Number(m[1]);
  if (/^exam_paper(\.pdf)?$/.test(f.replace(/\s*\(\d+\)/, ''))) return 1;
  const t = toHalfWidth(text.slice(0, 600));
  const r = t.match(/第\s*(\d{1,2})\s*回/);
  if (r) return Number(r[1]);
  const y = t.match(/(平成|令和)\s*(\d{1,2}|元)\s*年度/);
  if (y) {
    const n = y[2] === '元' ? 1 : Number(y[2]);
    // 平成21年度は第1〜4回の4回実施のため一意に決まらない
    if (y[1] === '平成' && n === 21) return null;
    const label = `${y[1]}${y[2] === '元' ? '元' : n}年度`;
    const hit = rows.filter((r2) => r2[1] === label);
    if (hit.length === 1) return hit[0][0];
  }
  return null;
}

export function toHalfWidth(s: string): string {
  return s.replace(/[０-９]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0));
}
