import { useState } from 'react';
import { useStore, unfinishedSession, studyPool, deleteSession } from '../lib/store';
import { overallStats } from '../lib/logic';
import { startBookmarks, startMock, startRandom, startToday, startUnanswered, startWeak, wrongQuestions } from '../lib/start';
import { navigate } from '../router';
import { Group, Icon, Row, formatDuration } from '../components/ui';

const SIZES = [10, 20, 30, 50] as const;

export function Home() {
  const st = useStore();
  const [size, setSize] = useState<(typeof SIZES)[number]>(10);
  const stats = overallStats(st.logs, Date.now());
  const goal = st.settings.dailyGoal;
  const pct = Math.min(100, Math.round((stats.today / goal) * 100));
  const resume = unfinishedSession();
  const pool = studyPool();
  const unanswered = pool.filter((q) => !st.progress.get(q.id)?.attemptCount).length;
  const wrong = wrongQuestions().length;
  const officialCount = st.questions.filter((q) => q.sourceType !== 'original').length;
  const pending = st.questions.filter((q) => !q.verified).length;
  const cycle = st.meta.cycleCompletedAt.length;

  return (
    <main className="page">
      <h1 className="screen-title">貸金業務取扱主任者<br />過去問</h1>

      {resume && (
        <div className="resume">
          <div className="grow">
            <b>{resume.title}</b> の途中です（{Object.keys(resume.answers).length} / {resume.questionIds.length}問）
            {resume.isExam && resume.timeLimitMs && (
              <div className="muted num">残り {formatDuration(resume.startTime + resume.timeLimitMs - Date.now())}</div>
            )}
          </div>
          <button className="btn small primary" onClick={() => navigate(`/s/${resume.id}`)}>再開</button>
          <button
            className="btn small"
            aria-label="途中のセッションを破棄"
            onClick={() => window.confirm('途中のセッションを破棄しますか？（回答済みの学習履歴は残ります）') && void deleteSession(resume.id)}
          >
            破棄
          </button>
        </div>
      )}

      <section className="today" aria-label="今日の学習">
        <div className="today-head">
          <span className="today-count num">
            {stats.today}
            <small>/ {goal}問</small>
          </span>
          <span className="muted small">{stats.streak > 0 ? `${stats.streak}日連続` : '今日の目標'}</span>
        </div>
        <div className="meter" role="progressbar" aria-valuemin={0} aria-valuemax={goal} aria-valuenow={stats.today} aria-label="今日の目標に対する回答数">
          <span style={{ width: `${pct}%` }} />
        </div>
        <p className="today-note">
          復習期限の問題、間違えた問題、まだ解いていない問題の順に出題します。
          {cycle > 0 && ` 全問題を${cycle}周しました。`}
        </p>
        <button className="btn primary block" onClick={() => void startToday()} disabled={!pool.length}>
          今日の学習をはじめる
        </button>
      </section>

      {officialCount === 0 && (
        <div className="notice info" style={{ marginTop: 14 }}>
          現在はオリジナル例題{st.questions.length}問のみです。公式過去問のPDFを取り込むと、過去問別・模試で使えるようになります。
          <div className="spacer" />
          <button className="btn small block" onClick={() => navigate('/import')}>
            <Icon name="download" />
            公式過去問を取り込む
          </button>
        </div>
      )}

      <Group title="演習">
        <div className="segmented" role="group" aria-label="出題数">
          {SIZES.map((n) => (
            <button key={n} aria-pressed={size === n} onClick={() => setSize(n)}>
              {n}問
            </button>
          ))}
        </div>
        <div style={{ padding: '8px 14px 14px' }}>
          <button className="btn block" onClick={() => void startRandom(size)} disabled={!pool.length}>
            <Icon name="shuffle" />
            ランダム{size}問をはじめる
          </button>
        </div>
        <Row icon="new" title="未出題のみ" value={`${unanswered}問`} onClick={() => void startUnanswered(size)} />
        <Row icon="alert" title="弱点問題" desc="正答率の低い分野から出題" onClick={() => void startWeak(size)} />
      </Group>

      <Group title="試験">
        <Row icon="clock" title="模擬試験" desc="50問・120分。終了後に採点と解説" onClick={() => void startMock()} />
        <Row icon="book" title="過去問（試験回別）" desc="本番と同じ順番で解く" href="/exams" />
        <Row icon="layers" title="分野別" href="/categories" />
      </Group>

      <Group title="復習">
        <Row icon="list" title="間違えた問題" value={`${wrong}問`} href="/wrong" />
        <Row icon="bookmark" title="ブックマーク" value={`${st.bookmarks.size}問`} href="/bookmarks" />
        {st.bookmarks.size > 0 && <Row icon="star" title="ブックマークのみ出題" onClick={() => void startBookmarks()} />}
      </Group>

      <Group title="その他">
        <Row icon="search" title="検索" href="/search" />
        <Row icon="chart" title="学習記録" href="/stats" />
        <Row icon="download" title="データの取込" desc="公式PDF・問題JSON・解説JSON" href="/import" />
        {pending > 0 && <Row icon="check" title="検証待ちの問題" value={`${pending}問`} href="/pending" />}
        <Row icon="gear" title="設定" href="/settings" />
      </Group>
      <p className="muted small" style={{ marginTop: 24 }}>
        収録 {st.questions.length}問（公式 {officialCount}・オリジナル {st.questions.length - officialCount}）。学習データはこの端末内にのみ保存されます。
      </p>
    </main>
  );
}
