import { useMemo, useState } from 'react';
import { CATEGORIES, type Category, type Question } from '../types';
import { getSearchIndex, setVerified, studyPool, useStore } from '../lib/store';
import { categorySummaries, fmtRate, mastery, MASTERY_LABEL, overallStats, searchQuestions, weakRanking } from '../lib/logic';
import { startBookmarks, startCategory, startExam, startIds, startWrong, wrongQuestions } from '../lib/start';
import { OFFICIAL_EXAMS, OFFICIAL_PAGE_URL, ORIGINAL_EXAM, getExam } from '../data/exams';
import { navigate } from '../router';
import { Empty, Group, Row, TopBar, formatDate } from '../components/ui';
import { questionLabel } from '../components/QuestionParts';

const PAGE = 100;

export function QuestionList({ list, emptyText, showMastery = true }: { list: Question[]; emptyText: string; showMastery?: boolean }) {
  const st = useStore();
  const [limit, setLimit] = useState(PAGE);
  if (!list.length) return <Empty>{emptyText}</Empty>;
  return (
    <>
      <div className="group">
        {list.slice(0, limit).map((q) => {
          const p = st.progress.get(q.id);
          return (
            <a key={q.id} className="row" href={`#/open/${encodeURIComponent(q.id)}`}>
              <span className="grow">
                <span className="title">{questionLabel(q)}<span className="muted small">　{q.category}</span></span>
                <span className="desc">{q.questionText.slice(0, 60)}{q.questionText.length > 60 ? '…' : ''}</span>
              </span>
              {showMastery && <span className="val small">{MASTERY_LABEL[mastery(p)]}{!q.verified ? '・未検証' : ''}</span>}
            </a>
          );
        })}
      </div>
      {list.length > limit && (
        <>
          <div className="spacer" />
          <button className="btn block" onClick={() => setLimit(limit + PAGE)}>さらに表示（残り{list.length - limit}問）</button>
        </>
      )}
    </>
  );
}

// ===== 過去問（試験回別） =====

export function ExamsScreen() {
  const st = useStore();
  const counts = useMemo(() => {
    const m = new Map<string, { all: number; verified: number }>();
    for (const q of st.questions) {
      const c = m.get(q.examId) ?? { all: 0, verified: 0 };
      c.all++;
      if (q.verified) c.verified++;
      m.set(q.examId, c);
    }
    return m;
  }, [st.questions]);
  return (
    <>
      <TopBar title="過去問（試験回別）" />
      <main className="page with-header">
        <p className="lead small">合格基準点は日本貸金業協会の公表値です。問題が未取込の回は「データの取込」から公式PDFを読み込んでください。</p>
        <Group>
          {[...OFFICIAL_EXAMS].reverse().map((e) => {
            const c = counts.get(e.examId);
            return (
              <Row
                key={e.examId}
                title={`第${e.round}回`}
                desc={`${e.examName.replace(/^第\d+回 貸金業務取扱主任者資格試験/, '').replace(/[（）]/g, '')}　${e.examDate.replaceAll('-', '/')}　合格基準 ${e.passingScore ?? '不明'}問`}
                value={c ? `${c.all}問` : '未取込'}
                href={`/exam/${e.examId}`}
              />
            );
          })}
          {counts.get(ORIGINAL_EXAM.examId) && <Row title="オリジナル例題" desc="公式問題ではありません" value={`${counts.get('original')!.all}問`} href="/exam/original" />}
        </Group>
      </main>
    </>
  );
}

export function ExamDetail({ examId }: { examId: string }) {
  const st = useStore();
  const exam = getExam(examId);
  const qs = st.questions.filter((q) => q.examId === examId).sort((a, b) => a.questionNumber - b.questionNumber);
  const unverified = qs.filter((q) => !q.verified).length;
  const answered = qs.filter((q) => st.progress.get(q.id)?.attemptCount).length;
  const past = [...st.sessions.values()].filter((s) => s.examId === examId && s.finished && s.result && s.isExam).sort((a, b) => b.startTime - a.startTime);
  return (
    <>
      <TopBar title={exam?.round ? `第${exam.round}回` : exam?.examName ?? examId} />
      <main className="page with-header">
        <p className="lead">{exam?.examName}</p>
        {exam?.passingScore != null && (
          <p className="small">
            合格基準点：<b>{exam.passingScore}問</b>（50問中）／試験日 {exam.examDate.replaceAll('-', '/')}
            <br />
            <span className="muted">{exam.passingScoreSource}</span>
          </p>
        )}
        {!qs.length ? (
          <Empty action={<div className="row-actions"><button className="btn primary" onClick={() => navigate('/import')}>PDFを取り込む</button><a className="btn" href={OFFICIAL_PAGE_URL} target="_blank" rel="noreferrer">公式サイトを開く</a></div>}>
            この回の問題はまだ取り込まれていません。公式サイトから「試験問題」と「正答」のPDFを保存し、取り込んでください。
          </Empty>
        ) : (
          <>
            <p className="small muted">収録 {qs.length}問・回答済み {answered}問{unverified ? `・未検証 ${unverified}問` : ''}</p>
            {qs.length !== (exam?.questionCount || qs.length) && <p className="notice">この回は{qs.length}問のみ収録されています（本試験は{exam?.questionCount}問）。本番形式でも合否判定は行いません。</p>}
            <div className="stack">
              <button className="btn primary block" onClick={() => void startExam(examId, false)}>学習モードで解く（1問ずつ解説）</button>
              {examId !== 'original' && <button className="btn block" onClick={() => void startExam(examId, true)}>本番形式で解く（120分・終了後に採点）</button>}
            </div>
            {!!past.length && (
              <Group title="この回の本番形式の結果">
                {past.slice(0, 10).map((s) => (
                  <Row key={s.id} title={`${s.result!.correct} / ${s.result!.total}問${s.result!.passed == null ? '' : s.result!.passed ? '　合格' : '　不合格'}`} desc={formatDate(s.startTime)} href={`/r/${s.id}`} />
                ))}
              </Group>
            )}
            <Group title="問題一覧">
              <QuestionList list={qs} emptyText="" />
            </Group>
          </>
        )}
      </main>
    </>
  );
}

// ===== 分野別 =====

export function CategoriesScreen() {
  const st = useStore();
  const sums = categorySummaries(studyPool(), st.progress);
  return (
    <>
      <TopBar title="分野別" />
      <main className="page with-header">
        <Group>
          {sums.map((s) => (
            <Row
              key={s.category}
              title={s.category}
              desc={`${s.questionCount}問　未回答 ${s.unansweredCount}　間違い ${s.wrongQuestionCount}`}
              value={s.attempts ? `${fmtRate(s.rate)}${s.tentative ? '*' : ''}` : '－'}
              href={`/category/${encodeURIComponent(s.category)}`}
            />
          ))}
        </Group>
        <p className="muted small">＊回答数が5回未満のため参考値</p>
      </main>
    </>
  );
}

export function CategoryDetail({ category }: { category: Category }) {
  const st = useStore();
  const pool = studyPool().filter((q) => q.category === category);
  const sum = categorySummaries(pool, st.progress).find((s) => s.category === category)!;
  const [n, setN] = useState(10);
  if (!CATEGORIES.includes(category)) return null;
  return (
    <>
      <TopBar title={category} />
      <main className="page with-header">
        <div className="stat-grid">
          <div className="stat"><div className="k">問題数</div><div className="v num">{sum.questionCount}<small>問</small></div></div>
          <div className="stat"><div className="k">正答率{sum.tentative && sum.attempts ? '（参考値）' : ''}</div><div className="v num">{sum.attempts ? fmtRate(sum.rate) : '－'}</div></div>
          <div className="stat"><div className="k">未回答</div><div className="v num">{sum.unansweredCount}<small>問</small></div></div>
          <div className="stat"><div className="k">間違い</div><div className="v num">{sum.wrongQuestionCount}<small>問</small></div></div>
        </div>
        <div className="segmented" style={{ padding: '14px 0 8px' }} role="group" aria-label="出題数">
          {[10, 20, 30, 50].map((x) => (
            <button key={x} aria-pressed={n === x} onClick={() => setN(x)}>{x}問</button>
          ))}
        </div>
        <button className="btn primary block" disabled={!pool.length} onClick={() => void startCategory(category, n)}>{category}を{Math.min(n, pool.length)}問解く</button>
        <Group title="問題一覧">
          <QuestionList list={pool} emptyText="この分野の問題はまだありません。" />
        </Group>
      </main>
    </>
  );
}

// ===== 間違い・ブックマーク・検証待ち =====

export function WrongScreen() {
  useStore();
  const list = wrongQuestions();
  return (
    <>
      <TopBar title="間違えた問題" />
      <main className="page with-header">
        <p className="lead small">直近の回答が不正解の問題です。正解すると一覧から外れます。</p>
        {!!list.length && <button className="btn primary block" onClick={() => void startWrong()}>間違えた問題だけ解く（{list.length}問）</button>}
        <div className="spacer" />
        <QuestionList list={list} emptyText="間違えた問題はありません。" />
      </main>
    </>
  );
}

export function BookmarksScreen() {
  const st = useStore();
  const list = [...st.bookmarks.values()].sort((a, b) => b.createdAt - a.createdAt).map((b) => st.qmap.get(b.questionId)).filter(Boolean) as Question[];
  return (
    <>
      <TopBar title="ブックマーク" />
      <main className="page with-header">
        {!!list.length && <button className="btn primary block" onClick={() => void startBookmarks()}>ブックマークのみ出題（{list.length}問）</button>}
        <div className="spacer" />
        <QuestionList list={list} emptyText="ブックマークした問題はありません。問題画面の右上から追加できます。" />
      </main>
    </>
  );
}

export function PendingScreen() {
  const st = useStore();
  const list = st.questions.filter((q) => !q.verified);
  return (
    <>
      <TopBar title="検証待ち" />
      <main className="page with-header">
        <p className="lead small">取り込んだ内容を原本と照合していない問題です。模擬試験からは除外されます（設定で変更可）。各問題の確認・修正は試験回ごとに「データの取込」から行えます。</p>
        {!!list.length && (
          <div className="stack">
            <button className="btn block" onClick={() => void startIds(list.map((q) => q.id), '検証待ちの問題')}>検証待ちの問題を解いてみる</button>
          </div>
        )}
        <div className="spacer" />
        <QuestionList list={list} emptyText="検証待ちの問題はありません。" />
        {!!list.length && (
          <>
            <div className="spacer" />
            <button
              className="btn danger block"
              onClick={() => {
                if (window.confirm(`検証待ちの${list.length}問すべてを「確認済み」にしますか？\n原本（公式PDF）と照合済みの場合のみ実行してください。`)) void setVerified(list.map((q) => q.id), true);
              }}
            >
              すべて確認済みにする
            </button>
          </>
        )}
      </main>
    </>
  );
}

// ===== 検索 =====

export function SearchScreen() {
  const st = useStore();
  const [query, setQuery] = useState('');
  const results = useMemo(() => (query.trim() ? searchQuestions(st.questions, getSearchIndex(), query) : []), [query, st.questions]);
  return (
    <>
      <TopBar title="検索" />
      <main className="page with-header">
        <div className="search-box">
          <input
            className="input"
            type="search"
            inputMode="search"
            enterKeyHint="search"
            placeholder="例：総量規制、利息制限法、第13条の2"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            aria-label="問題文・選択肢・解説・条文を検索"
            autoFocus
          />
        </div>
        {query.trim() && (
          <p className="small muted" aria-live="polite">{results.length}件{results.length ? '（スペース区切りで絞り込み）' : ''}</p>
        )}
        {!!results.length && (
          <>
            <button className="btn block" onClick={() => void startIds(results.slice(0, 50).map((q) => q.id), `検索：${query}`, 'search')}>
              検索結果を出題（{Math.min(50, results.length)}問）
            </button>
            <div className="spacer" />
          </>
        )}
        {query.trim() ? <QuestionList list={results} emptyText="該当する問題はありません。" /> : <p className="muted small">問題文・選択肢・解説・法律名・条文・分野を対象に検索します。</p>}
      </main>
    </>
  );
}

// ===== 学習記録 =====

export function StatsScreen() {
  const st = useStore();
  const o = overallStats(st.logs, Date.now());
  const sums = categorySummaries(st.questions, st.progress);
  const ranking = weakRanking(sums);
  const wrong = wrongQuestions().length;
  const mocks = [...st.sessions.values()].filter((s) => s.isExam && s.finished && s.result).sort((a, b) => b.startTime - a.startTime);
  const counts = { unanswered: 0, weak: 0, review: 0, mastered: 0 };
  for (const q of st.questions) counts[mastery(st.progress.get(q.id))]++;
  return (
    <>
      <TopBar title="学習記録" />
      <main className="page with-header">
        <div className="stat-grid">
          <div className="stat"><div className="k">累計回答数</div><div className="v num">{o.totalAnswers}<small>回</small></div></div>
          <div className="stat"><div className="k">累計正答率</div><div className="v num">{o.totalAnswers ? fmtRate(o.rate) : '－'}</div></div>
          <div className="stat"><div className="k">正解／不正解</div><div className="v num">{o.correct}<small> / {o.wrong}</small></div></div>
          <div className="stat"><div className="k">連続学習</div><div className="v num">{o.streak}<small>日</small></div></div>
          <div className="stat"><div className="k">今日の回答</div><div className="v num">{o.today}<small>問</small></div></div>
          <div className="stat"><div className="k">今週の回答</div><div className="v num">{o.week}<small>問</small></div></div>
          <div className="stat"><div className="k">ブックマーク</div><div className="v num">{st.bookmarks.size}<small>問</small></div></div>
          <div className="stat"><div className="k">間違い問題</div><div className="v num">{wrong}<small>問</small></div></div>
        </div>

        <Group title="理解度">
          <Row title="習得" value={`${counts.mastered}問`} />
          <Row title="要復習" value={`${counts.review}問`} />
          <Row title="苦手" desc="2回以上間違え、直近も不正解" value={`${counts.weak}問`} />
          <Row title="未回答" value={`${counts.unanswered}問`} />
          <Row title="全問1周" value={st.meta.cycleCompletedAt.length ? `${st.meta.cycleCompletedAt.length}周（最終 ${formatDate(st.meta.cycleCompletedAt.at(-1))}）` : 'まだ'} />
        </Group>

        <Group title="弱点ランキング">
          {ranking.length ? (
            ranking.map((s, i) => (
              <Row key={s.category} title={`${i + 1}位　${s.category}`} desc={`回答 ${s.attempts}回・間違い問題 ${s.wrongQuestionCount}問${s.tentative ? '・参考値' : ''}`} value={fmtRate(s.rate)} href={`/category/${encodeURIComponent(s.category)}`} />
            ))
          ) : (
            <Row title="まだ回答がありません" />
          )}
        </Group>

        <Group title="模試の結果">
          {mocks.length ? (
            mocks.slice(0, 20).map((s) => (
              <Row key={s.id} title={`${s.title}　${s.result!.correct}/${s.result!.total}`} desc={formatDate(s.startTime)} value={s.result!.passed == null ? '' : s.result!.passed ? '合格' : '不合格'} href={`/r/${s.id}`} />
            ))
          ) : (
            <Row title="まだ模試を受けていません" />
          )}
        </Group>
      </main>
    </>
  );
}
