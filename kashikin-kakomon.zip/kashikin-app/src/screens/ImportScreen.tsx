import { useEffect, useRef, useState } from 'react';
import { CATEGORIES, type Category, type ChoiceId, type Question } from '../types';
import { OFFICIAL_EXAMS, OFFICIAL_PAGE_URL, getExam, guessRound, pad2 } from '../data/exams';
import { detectKind, parseAnswerKey, parsePaper, type ParsedQuestion } from '../lib/pdfParse';
import { extractLines, openPdf, renderPage, type PDFDocumentProxy } from '../lib/pdfExtract';
import { importQuestionsJson, saveQuestions, showToast, useStore } from '../lib/store';
import { choiceMark } from '../lib/logic';
import { validateQuestion } from '../lib/validate';
import { Group, Icon, TopBar } from '../components/ui';

interface RoundBundle {
  key: string;
  round: number | null;
  paperName?: string;
  doc?: PDFDocumentProxy;
  parsed?: ParsedQuestion[];
  paperWarnings: string[];
  answerName?: string;
  answers?: Map<number, ChoiceId>;
  answerWarnings: string[];
}

interface Draft {
  seq: number;
  questionNumber: number;
  questionText: string;
  items: { label: string; text: string }[];
  choices: string[];
  correctAnswer: ChoiceId | null;
  category: Category;
  annotations: { text: string; anchorText: string | null }[];
  pages: number[];
  issues: string[];
  verified: boolean;
  include: boolean;
}

type Log = { kind: 'ok' | 'warn' | 'err'; text: string };

export function ImportScreen() {
  const st = useStore();
  const [bundles, setBundles] = useState<RoundBundle[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [logs, setLogs] = useState<Log[]>([]);
  const [reviewKey, setReviewKey] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const addLog = (l: Log) => setLogs((x) => [...x, l]);

  const onFiles = async (files: FileList) => {
    setLogs([]);
    const next = [...bundles];
    const findOrCreate = (round: number | null, fallbackKey: string) => {
      const key = round != null ? `r${round}` : fallbackKey;
      let b = next.find((x) => x.key === key);
      if (!b) {
        b = { key, round, paperWarnings: [], answerWarnings: [] };
        next.push(b);
      }
      return b;
    };
    for (const f of Array.from(files)) {
      setBusy(`${f.name} を読み込んでいます…`);
      try {
        if (/\.json$/i.test(f.name) || f.type === 'application/json') {
          const r = await importQuestionsJson(JSON.parse(await f.text()));
          addLog({ kind: r.rejected.length ? 'warn' : 'ok', text: `${f.name}：追加 ${r.added}問・更新 ${r.updated}問・解説統合 ${r.explained}問${r.rejected.length ? `・不備により除外 ${r.rejected.length}件（${r.rejected.slice(0, 3).map((x) => `${x.id}: ${x.errors[0]}`).join('／')}）` : ''}${r.notFound.length ? `・該当問題なし ${r.notFound.length}件` : ''}` });
          continue;
        }
        const buf = await f.arrayBuffer();
        const doc = await openPdf(buf);
        const pages = await extractLines(doc);
        const text = pages.map((p) => p.lines.join('\n')).join('\n');
        const kind = detectKind(f.name, text);
        const round = guessRound(f.name, text);
        if (!text.trim()) {
          addLog({ kind: 'err', text: `${f.name}：文字情報がないPDFです（画像のみのPDFは現在取り込めません）` });
          continue;
        }
        if (kind === 'answer') {
          const r = parseAnswerKey(text);
          const b = findOrCreate(round, `a-${f.name}`);
          b.answerName = f.name;
          b.answers = r.answers;
          b.answerWarnings = r.warnings;
          addLog({ kind: r.warnings.length ? 'warn' : 'ok', text: `${f.name}：正答 ${r.answers.size}問を読み取りました${round ? `（第${round}回と判定）` : '（試験回を選択してください）'}` });
        } else if (kind === 'paper') {
          const r = parsePaper(pages);
          const b = findOrCreate(round, `p-${f.name}`);
          b.paperName = f.name;
          b.doc = doc;
          b.parsed = r.questions;
          b.paperWarnings = r.warnings;
          const issues = r.questions.filter((q) => q.issues.length).length;
          addLog({ kind: issues || r.warnings.length ? 'warn' : 'ok', text: `${f.name}：${r.questions.length}問を検出、要確認 ${issues}問${round ? `（第${round}回と判定）` : '（試験回を選択してください）'}` });
        } else {
          addLog({ kind: 'err', text: `${f.name}：試験問題用紙・正答のどちらとも判定できませんでした` });
        }
      } catch (e) {
        addLog({ kind: 'err', text: `${f.name}：読み込みに失敗しました（${e instanceof Error ? e.message : String(e)}）` });
      }
    }
    setBundles(next);
    setBusy(null);
    if (fileRef.current) fileRef.current.value = '';
  };

  const setRound = (key: string, round: number) => {
    setBundles((bs) => {
      const b = bs.find((x) => x.key === key)!;
      const other = bs.find((x) => x.key !== key && x.round === round);
      if (other) {
        // 同じ回の問題用紙と正答をまとめる
        const merged: RoundBundle = {
          ...other,
          ...Object.fromEntries(Object.entries(b).filter(([, v]) => v !== undefined)),
          key: `r${round}`,
          round,
          paperWarnings: b.parsed ? b.paperWarnings : other.paperWarnings,
          answerWarnings: b.answers ? b.answerWarnings : other.answerWarnings,
        } as RoundBundle;
        return [...bs.filter((x) => x.key !== key && x.key !== other.key), merged];
      }
      return bs.map((x) => (x.key === key ? { ...x, round, key: `r${round}` } : x));
    });
  };

  const review = bundles.find((b) => b.key === reviewKey);
  if (review && review.parsed && review.round != null) {
    return <ReviewRound bundle={review} onClose={() => setReviewKey(null)} onDone={() => { setBundles((bs) => bs.filter((b) => b.key !== review.key)); setReviewKey(null); }} />;
  }

  return (
    <>
      <TopBar title="データの取込" />
      <main className="page with-header">
        <section className="stack">
          <p className="lead" style={{ margin: 0 }}>
            日本貸金業協会の公式サイトで公開されている「試験問題」と「正答」のPDFを、この端末内で読み取って問題データにします。読み取りはすべて端末内で行い、外部へは送信しません。
          </p>
          <ol className="small" style={{ margin: 0, paddingLeft: '1.3em', lineHeight: 1.8 }}>
            <li>公式サイトを開き、取り込みたい回の「試験問題」と「正答」のPDFを開いて、共有ボタンから「"ファイル"に保存」します。</li>
            <li>下の「ファイルを選ぶ」から、保存したPDFを選びます（複数まとめて選べます）。</li>
            <li>読み取った内容を原本と見比べて確認し、登録します。</li>
          </ol>
          <a className="btn block" href={OFFICIAL_PAGE_URL} target="_blank" rel="noreferrer">
            公式サイト（試験問題・過去問題等）を開く
          </a>
          <button className="btn primary block" onClick={() => fileRef.current?.click()} disabled={!!busy}>
            <Icon name="upload" />
            ファイルを選ぶ（PDF・JSON）
          </button>
          <input ref={fileRef} type="file" accept="application/pdf,.pdf,application/json,.json" multiple hidden onChange={(e) => e.target.files?.length && void onFiles(e.target.files)} />
          {busy && <p className="notice info" aria-live="polite">{busy}</p>}
          {logs.map((l, i) => (
            <p key={i} className={`notice${l.kind === 'ok' ? ' info' : ''}`} style={l.kind === 'err' ? { background: 'var(--ng-soft)', color: 'var(--ng)' } : undefined}>
              {l.text}
            </p>
          ))}
        </section>

        {bundles.length > 0 && (
          <Group title="読み取り結果">
            {bundles.map((b) => {
              const exists = b.round != null ? st.questions.filter((q) => q.examId === `exam${pad2(b.round!)}`).length : 0;
              return (
                <div key={b.key} style={{ padding: 14, borderTop: '1px solid var(--rule)' }} className="stack">
                  <label className="field" style={{ margin: 0 }}>
                    <span>試験回</span>
                    <select className="select" value={b.round ?? ''} onChange={(e) => setRound(b.key, Number(e.target.value))}>
                      <option value="" disabled>選択してください</option>
                      {OFFICIAL_EXAMS.map((e) => (
                        <option key={e.examId} value={e.round!}>第{e.round}回（{e.examDate.slice(0, 4)}年）</option>
                      ))}
                    </select>
                  </label>
                  <div className="small">
                    問題用紙：{b.parsed ? `${b.parsed.length}問（${b.paperName}）` : <span className="muted">未選択</span>}
                    <br />
                    正答：{b.answers ? `${b.answers.size}問（${b.answerName}）` : <span className="muted">未選択（登録時に手入力が必要）</span>}
                  </div>
                  {[...b.paperWarnings, ...b.answerWarnings].map((w, i) => (
                    <p key={i} className="notice" style={{ margin: 0 }}>{w}</p>
                  ))}
                  {exists > 0 && <p className="notice" style={{ margin: 0 }}>この回はすでに{exists}問登録されています。登録すると問題文・正答を上書きします（学習履歴と解説は保持）。</p>}
                  <button className="btn primary" disabled={!b.parsed || b.round == null} onClick={() => setReviewKey(b.key)}>
                    内容を確認して登録へ進む
                  </button>
                </div>
              );
            })}
          </Group>
        )}

        <Group title="JSONでの取込">
          <div style={{ padding: 14 }} className="small">
            <p style={{ marginTop: 0 }}>次の2種類のJSONを同じ「ファイルを選ぶ」から読み込めます。</p>
            <ul style={{ paddingLeft: '1.2em', lineHeight: 1.8, margin: 0 }}>
              <li><b>問題データ</b>：{'{ "questions": [ … ] }'}。他の端末から書き出したものや、自作の問題。</li>
              <li><b>解説データ</b>：{'{ "explanations": [ { "questionId": "exam12-q001", "explanation": { … }, "legalBasis": [ … ] } ] }'}。既存の問題に選択肢ごとの解説・根拠を追加します。誤り箇所の引用が問題文と一致しない場合は警告を表示します。</li>
            </ul>
            <p className="muted">形式の詳細は同梱の docs/DATA_FORMAT.md を参照してください。</p>
          </div>
        </Group>
      </main>
    </>
  );
}

// ===== 確認画面 =====

function toDrafts(b: RoundBundle, existing: Map<string, Question>): Draft[] {
  return b.parsed!.map((p) => {
    const qn = p.markerNumber ?? p.seq;
    const ans = b.answers?.get(qn) ?? null;
    const issues = [...p.issues];
    if (b.answers && ans == null) issues.push('正答PDFにこの問題の正答がありません');
    if (!b.answers) issues.push('正答が未入力です');
    const prev = existing.get(`exam${pad2(b.round!)}-q${String(qn).padStart(3, '0')}`);
    return {
      seq: p.seq,
      questionNumber: qn,
      questionText: p.questionText,
      items: p.items.map((i) => ({ ...i })),
      choices: p.choices.map((c) => c.text),
      correctAnswer: ans,
      category: prev?.category ?? p.guessedCategory,
      annotations: p.annotations,
      pages: p.pages,
      issues,
      verified: false,
      include: true,
    };
  });
}

function ReviewRound({ bundle, onClose, onDone }: { bundle: RoundBundle; onClose: () => void; onDone: () => void }) {
  const st = useStore();
  const exam = getExam(`exam${pad2(bundle.round!)}`)!;
  const [drafts, setDrafts] = useState<Draft[]>(() => toDrafts(bundle, st.qmap));
  const [saving, setSaving] = useState(false);
  const clean = drafts.filter((d) => !d.issues.length);
  const update = (seq: number, patch: Partial<Draft>) => setDrafts((ds) => ds.map((d) => (d.seq === seq ? { ...d, ...patch } : d)));

  const build = (d: Draft): Question => {
    const id = `${exam.examId}-q${String(d.questionNumber).padStart(3, '0')}`;
    const prev = st.qmap.get(id);
    return {
      id,
      examId: exam.examId,
      examName: exam.examName,
      questionNumber: d.questionNumber,
      category: d.category,
      subcategory: prev?.subcategory,
      questionText: d.questionText.trim(),
      items: d.items.length ? d.items.map((i) => ({ label: i.label, text: i.text.trim() })) : undefined,
      choices: d.choices.map((t, i) => ({ id: (i + 1) as ChoiceId, text: t.trim() })),
      correctAnswer: d.correctAnswer as ChoiceId,
      annotations: d.annotations.length ? d.annotations : undefined,
      explanation: prev?.explanation,
      legalBasis: prev?.legalBasis,
      relatedQuestionIds: prev?.relatedQuestionIds,
      sourceType: 'official',
      source: `日本貸金業協会 公表PDF（${bundle.paperName ?? ''}${bundle.answerName ? ` / ${bundle.answerName}` : ''}）を端末内で読み取り`,
      verified: d.verified,
      issues: d.issues.length ? d.issues : undefined,
      importedAt: Date.now(),
    };
  };

  const register = async () => {
    const targets = drafts.filter((d) => d.include);
    const built = targets.map(build);
    const bad = built.map((q) => ({ q, r: validateQuestion(q) })).filter((x) => !x.r.ok);
    const dupNums = targets.map((d) => d.questionNumber).filter((n, i, a) => a.indexOf(n) !== i);
    if (dupNums.length) {
      window.alert(`問題番号が重複しています：${[...new Set(dupNums)].join('、')}。番号を修正してください。`);
      return;
    }
    const ok = built.filter((q) => !bad.some((b) => b.q.id === q.id));
    const verifiedN = ok.filter((q) => q.verified).length;
    const msg = `この内容で登録しますか？\n\n登録：${ok.length}問（確認済み ${verifiedN}問・未検証 ${ok.length - verifiedN}問）${bad.length ? `\n不備のため登録しない：${bad.length}問（${bad.slice(0, 5).map((b) => `問${b.q.questionNumber}`).join('、')}${bad.length > 5 ? ' ほか' : ''}）` : ''}`;
    if (!window.confirm(msg)) return;
    setSaving(true);
    try {
      await saveQuestions(ok);
      showToast(`第${exam.round}回を${ok.length}問登録しました`);
      onDone();
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <TopBar title={`第${exam.round}回の確認`} left={<button className="icon-btn" onClick={onClose}><Icon name="back" />戻る</button>} />
      <main className="page with-header with-footer">
        <p className="lead small">
          読み取った内容を原本（PDF）と見比べてください。特に「及び／又は」「できる／できない」、数字・条文番号・％・金額・期間、「以上／以下／未満／超える」を確認します。原本と一致すると確認できた問題だけ「原本と照合済み」にしてください。
        </p>
        {[...bundle.paperWarnings, ...bundle.answerWarnings].map((w, i) => (
          <p key={i} className="notice">{w}</p>
        ))}
        <p className="small">要確認 {drafts.length - clean.length}問／問題なし {clean.length}問</p>
        {clean.length > 0 && (
          <button
            className="btn block"
            onClick={() => {
              if (window.confirm(`要確認事項が検出されなかった${clean.length}問を「原本と照合済み」にしますか？\n自動判定では誤読を完全には検出できません。原本と照合したうえで実行してください。`))
                setDrafts((ds) => ds.map((d) => (d.issues.length ? d : { ...d, verified: true })));
            }}
          >
            要確認事項のない{clean.length}問を照合済みにする
          </button>
        )}
        <div className="spacer" />
        {drafts.map((d) => (
          <DraftCard key={d.seq} d={d} doc={bundle.doc} onChange={(p) => update(d.seq, p)} />
        ))}
      </main>
      <footer className="footbar">
        <div className="footbar-inner">
          <button className="btn" onClick={onClose}>戻る</button>
          <button className="btn primary" disabled={saving} onClick={() => void register()}>この内容で登録</button>
        </div>
      </footer>
    </>
  );
}

function DraftCard({ d, doc, onChange }: { d: Draft; doc?: PDFDocumentProxy; onChange: (p: Partial<Draft>) => void }) {
  const [edit, setEdit] = useState(false);
  const [showPage, setShowPage] = useState(false);
  return (
    <article className={`import-q${d.issues.length ? ' has-issue' : ''}`}>
      <h3>
        <span className="num">問{d.questionNumber}</span>
        {d.issues.length ? <span className="tag warn">要確認</span> : <span className="tag">問題なし</span>}
        {d.verified && <span className="tag orig">照合済み</span>}
      </h3>
      {d.issues.map((i, k) => (
        <p key={k} className="notice" style={{ marginBottom: 8 }}>{i}</p>
      ))}
      {!edit ? (
        <>
          <p className="q-text jp" style={{ fontSize: 15.5 }}>{d.questionText || <span className="muted">（問題文なし）</span>}</p>
          {d.items.map((it) => (
            <p key={it.label} className="jp" style={{ margin: '0 0 6px', fontFamily: 'var(--font-text)', fontSize: 15 }}>{it.label}　{it.text}</p>
          ))}
          {d.choices.map((c, i) => (
            <p key={i} className="jp" style={{ margin: '0 0 6px', fontFamily: 'var(--font-text)', fontSize: 15 }}>
              {choiceMark(i + 1)}　{c || <span className="muted">（空）</span>}
            </p>
          ))}
          {d.annotations.map((a, i) => (
            <p key={i} className="annot jp">注釈　{a.text}</p>
          ))}
        </>
      ) : (
        <div>
          <label className="field">
            <span>問題番号</span>
            <input className="input num" type="number" inputMode="numeric" value={d.questionNumber} onChange={(e) => onChange({ questionNumber: Number(e.target.value) })} />
          </label>
          <label className="field">
            <span>問題文</span>
            <textarea className="textarea" rows={5} value={d.questionText} onChange={(e) => onChange({ questionText: e.target.value })} />
          </label>
          {d.items.map((it, k) => (
            <label key={it.label} className="field">
              <span>小問 {it.label}</span>
              <textarea className="textarea" rows={3} value={it.text} onChange={(e) => onChange({ items: d.items.map((x, j) => (j === k ? { ...x, text: e.target.value } : x)) })} />
            </label>
          ))}
          {d.choices.map((c, k) => (
            <label key={k} className="field">
              <span>選択肢 {choiceMark(k + 1)}</span>
              <textarea className="textarea" rows={2} value={c} onChange={(e) => onChange({ choices: d.choices.map((x, j) => (j === k ? e.target.value : x)) })} />
            </label>
          ))}
        </div>
      )}
      <div className="row-actions" style={{ margin: '8px 0 12px' }}>
        <label className="field" style={{ margin: 0, flex: 1 }}>
          <span>正答</span>
          <select className="select" value={d.correctAnswer ?? ''} onChange={(e) => onChange({ correctAnswer: Number(e.target.value) as ChoiceId })}>
            <option value="" disabled>未入力</option>
            {[1, 2, 3, 4].map((n) => (
              <option key={n} value={n}>{choiceMark(n)}</option>
            ))}
          </select>
        </label>
        <label className="field" style={{ margin: 0, flex: 2 }}>
          <span>分野</span>
          <select className="select" value={d.category} onChange={(e) => onChange({ category: e.target.value as Category })}>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </label>
      </div>
      <div className="row-actions">
        <button className="btn small" onClick={() => setEdit(!edit)}>{edit ? '編集を閉じる' : '修正する'}</button>
        {doc && <button className="btn small" onClick={() => setShowPage(!showPage)}>{showPage ? '原本を閉じる' : `原本を表示（${d.pages.join('・')}ページ）`}</button>}
      </div>
      {showPage && doc && d.pages.map((p) => <PageView key={p} doc={doc} page={p} />)}
      <div className="spacer" />
      <label className="check-row">
        <input type="checkbox" checked={d.verified} onChange={(e) => onChange({ verified: e.target.checked })} />
        <span>原本と照合済み（模試で出題する）</span>
      </label>
      <div className="spacer" />
      <label className="check-row">
        <input type="checkbox" checked={d.include} onChange={(e) => onChange({ include: e.target.checked })} />
        <span>この問題を登録する</span>
      </label>
    </article>
  );
}

function PageView({ doc, page }: { doc: PDFDocumentProxy; page: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const wrap = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (ref.current && wrap.current) void renderPage(doc, page, ref.current, wrap.current.clientWidth);
  }, [doc, page]);
  return (
    <div className="page-canvas" ref={wrap} aria-label={`原本 ${page}ページ`}>
      <canvas ref={ref} />
    </div>
  );
}
