import { useRef, useState } from 'react';
import type { FontSize, ThemeSetting } from '../types';
import {
  buildBackup,
  buildQuestionsExport,
  downloadJson,
  resetLearning,
  restoreBackup,
  showToast,
  updateSettings,
  useStore,
} from '../lib/store';
import { Group, Row, TopBar } from '../components/ui';
import { OFFICIAL_EXAMS } from '../data/exams';

declare const __APP_VERSION__: string;

function today() {
  const d = new Date();
  return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
}

export function SettingsScreen() {
  const st = useStore();
  const s = st.settings;
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  const onRestore = async (f: File) => {
    setBusy(true);
    try {
      const data = JSON.parse(await f.text());
      if (!window.confirm('現在の学習データを、バックアップの内容で置き換えますか？（問題データは変わりません）')) return;
      showToast(await restoreBackup(data));
    } catch (e) {
      window.alert(`復元できませんでした：${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  return (
    <>
      <TopBar title="設定" />
      <main className="page with-header">
        <Group title="表示">
          <div style={{ padding: 14 }}>
            <label className="field">
              <span>テーマ</span>
              <select className="select" value={s.theme} onChange={(e) => void updateSettings({ theme: e.target.value as ThemeSetting })}>
                <option value="system">システム設定に従う</option>
                <option value="light">ライト</option>
                <option value="dark">ダーク</option>
              </select>
            </label>
            <label className="field">
              <span>問題文の文字サイズ</span>
              <select className="select" value={s.fontSize} onChange={(e) => void updateSettings({ fontSize: e.target.value as FontSize })}>
                <option value="small">小（16px）</option>
                <option value="medium">標準（17px）</option>
                <option value="large">大（18px）</option>
              </select>
            </label>
            <label className="switch-row">
              <input type="checkbox" checked={s.showCategoryOnQuestion} onChange={(e) => void updateSettings({ showCategoryOnQuestion: e.target.checked })} />
              <span>解答前に分野を表示する</span>
            </label>
          </div>
        </Group>

        <Group title="出題">
          <div style={{ padding: 14 }} className="stack">
            <label className="field" style={{ marginBottom: 4 }}>
              <span>1日の目標（今日の学習の出題数）</span>
              <select className="select" value={s.dailyGoal} onChange={(e) => void updateSettings({ dailyGoal: Number(e.target.value) })}>
                {[10, 20, 30, 50].map((n) => (
                  <option key={n} value={n}>{n}問</option>
                ))}
              </select>
            </label>
            <label className="switch-row">
              <input type="checkbox" checked={s.includeUnverifiedInMock} onChange={(e) => void updateSettings({ includeUnverifiedInMock: e.target.checked })} />
              <span>未検証の問題を模擬試験に含める</span>
            </label>
            <label className="switch-row">
              <input type="checkbox" checked={s.includeUnverifiedInStudy} onChange={(e) => void updateSettings({ includeUnverifiedInStudy: e.target.checked })} />
              <span>未検証の問題を通常の演習に含める（「未検証」と表示）</span>
            </label>
          </div>
        </Group>

        <Group title="データ">
          <Row title="学習データをバックアップ" desc="回答履歴・ブックマーク・設定・統計・出題履歴（JSON）" onClick={() => downloadJson(`kashikin-backup-${today()}.json`, buildBackup())} />
          <Row title="学習データを復元" desc="バックアップJSONを読み込む" onClick={() => fileRef.current?.click()} disabled={busy} />
          <Row title="問題データを書き出す" desc="取り込んだ問題を別の端末へ移すとき用（JSON）" onClick={() => downloadJson(`kashikin-questions-${today()}.json`, buildQuestionsExport())} />
          <Row title="データの取込" href="/import" />
          <Row title="問題データ情報" href="/data" />
        </Group>
        <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={(e) => e.target.files?.[0] && void onRestore(e.target.files[0])} />

        <Group title="リセット">
          <div style={{ padding: 14 }}>
            <button
              className="btn danger block"
              onClick={() => {
                if (!window.confirm('学習履歴をすべて削除しますか？\n回答履歴・ブックマーク・模試結果・統計が消えます。問題データは削除されません。')) return;
                if (!window.confirm('本当に削除しますか？この操作は元に戻せません。')) return;
                void resetLearning().then(() => showToast('学習履歴をすべて削除しました'));
              }}
            >
              学習履歴をすべて削除
            </button>
          </div>
        </Group>

        <Group title="アプリ情報">
          <Row title="バージョン" value={typeof __APP_VERSION__ === 'string' ? __APP_VERSION__ : 'dev'} />
          <Row title="データの保存先" desc="この端末のブラウザ内（IndexedDB）のみ。外部サーバーへの送信、ログイン、AI APIの利用はありません。" />
        </Group>
      </main>
    </>
  );
}

export function DataInfoScreen() {
  const st = useStore();
  const byExam = new Map<string, number>();
  for (const q of st.questions) byExam.set(q.examId, (byExam.get(q.examId) ?? 0) + 1);
  const noExpl = st.questions.filter((q) => !q.explanation).length;
  return (
    <>
      <TopBar title="問題データ情報" />
      <main className="page with-header">
        <Group>
          <Row title="収録問題数" value={`${st.questions.length}問`} />
          <Row title="公式過去問" value={`${st.questions.filter((q) => q.sourceType !== 'original').length}問`} />
          <Row title="オリジナル例題" value={`${st.questions.filter((q) => q.sourceType === 'original').length}問`} />
          <Row title="未検証" value={`${st.questions.filter((q) => !q.verified).length}問`} href="/pending" />
          <Row title="解説未登録" value={`${noExpl}問`} />
          <Row title="データ不備で除外" value={`${st.invalid.length}問`} />
        </Group>
        {!!st.invalid.length && (
          <Group title="除外された問題（アプリは停止せず、この問題だけ出題しません）">
            {st.invalid.slice(0, 50).map((i) => (
              <Row key={i.id} title={i.id} desc={i.errors.join('／')} />
            ))}
          </Group>
        )}
        {!!st.bundleWarnings.length && <p className="notice">{st.bundleWarnings.join('\n')}</p>}
        <Group title="試験回別">
          {OFFICIAL_EXAMS.map((e) => (
            <Row key={e.examId} title={`第${e.round}回`} desc={`合格基準 ${e.passingScore ?? '不明'}問`} value={`${byExam.get(e.examId) ?? 0} / ${e.questionCount}問`} />
          ))}
        </Group>
      </main>
    </>
  );
}
