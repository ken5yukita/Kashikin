import { useEffect, useMemo, useRef, useState } from 'react';
import type { ChoiceId, Question, Session } from '../types';
import { answer, finishSession, getState, setIndex, toggleBookmark, useStore } from '../lib/store';
import { navigate } from '../router';
import { HomeButton, Icon, TopBar, formatDuration } from '../components/ui';
import { ChoiceList, ExplanationView, QuestionBody, QuestionMeta, Verdict } from '../components/QuestionParts';

export function SessionScreen({ id, startAt }: { id: string; startAt: number | null }) {
  const st = useStore();
  const s = st.sessions.get(id);
  const [showSheet, setShowSheet] = useState(false);
  const idx = s ? Math.min(Math.max(startAt ?? s.currentIndex, 0), s.questionIds.length - 1) : 0;

  useEffect(() => {
    if (s && startAt != null && startAt !== s.currentIndex) void setIndex(s.id, idx);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [startAt]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [idx]);

  if (!s) {
    return (
      <div className="page center-msg">
        <div>
          <p>このセッションは見つかりません。</p>
          <button className="btn" onClick={() => navigate('/')}>ホームへ</button>
        </div>
      </div>
    );
  }

  const qid = s.questionIds[idx];
  const q = st.qmap.get(qid);
  const total = s.questionIds.length;
  const selected = s.answers[qid];
  const review = s.finished;
  const reveal = review || (!s.isExam && !!s.locked[qid]);
  const examRunning = s.isExam && !s.finished;

  const go = (i: number) => {
    void setIndex(s.id, i);
    navigate(`/s/${s.id}`, { replace: true });
  };

  const goHome = () => {
    if (examRunning) {
      const ok = window.confirm('模試を中断してホームに戻りますか？\n解答は保存され、ホームから再開できます。\n（残り時間は本番と同様に進み続けます）');
      if (!ok) return;
    }
    navigate('/');
  };

  const finish = async () => {
    if (s.isExam) {
      const un = s.questionIds.filter((x) => !s.answers[x]).length;
      const msg = un ? `未解答が${un}問あります。模試を終了して採点しますか？` : '模試を終了して採点しますか？';
      if (!window.confirm(msg)) return;
    }
    await finishSession(s.id);
    navigate(`/r/${s.id}`, { replace: true });
  };

  const onSelect = (c: ChoiceId) => {
    if (review) return;
    const wasLocked = !!s.locked[qid];
    void answer(s.id, qid, c).then(() => {
      // 学習モード：回答直後に○×が画面外なら見える位置までスクロール
      if (!s.isExam && !wasLocked) {
        requestAnimationFrame(() => {
          const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
          document.querySelector('.verdict')?.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'nearest' });
        });
      }
    });
  };

  const isLast = idx === total - 1;
  const bookmarked = st.bookmarks.has(qid);

  return (
    <>
      <TopBar
        left={<HomeButton onClick={goHome} />}
        title={<span className="num">{idx + 1} / {total}</span>}
        sub={examRunning && s.timeLimitMs ? <Timer session={s} onTimeUp={() => void autoFinish(s.id)} /> : review ? '見直し' : s.title}
        right={
          <button
            className={`icon-btn${bookmarked ? ' bookmark-on' : ''}`}
            onClick={() => void toggleBookmark(qid)}
            aria-pressed={bookmarked}
            aria-label={bookmarked ? 'ブックマークを外す' : 'ブックマークに追加'}
          >
            <Icon name={bookmarked ? 'bookmark-fill' : 'bookmark'} />
          </button>
        }
      />
      <main className="page with-header with-footer">
        {!q ? (
          <p className="notice">この問題は削除されたか、データの検証で除外されています（ID：{qid}）。「次へ」で先に進めます。</p>
        ) : (
          <>
            <QuestionMeta q={q} showCategory={st.settings.showCategoryOnQuestion || reveal} />
            <QuestionBody q={q} />
            {examRunning && <p className="sr-only">模擬試験中は解答後も正誤を表示しません。解答は変更できます。</p>}
            <ChoiceList q={q} selected={selected} reveal={reveal} disabled={review || (!s.isExam && !!s.locked[qid])} onSelect={onSelect} />
            {reveal && selected && <Verdict q={q} selected={selected} />}
            {reveal && !selected && <p className="notice">この問題は未解答でした。正答は下の解説を確認してください。</p>}
            {reveal && <ExplanationView q={q} related={relatedOf(q)} />}
            {examRunning && (
              <button className="btn block" onClick={() => setShowSheet(true)}>
                <Icon name="grid" />
                解答一覧・終了
              </button>
            )}
          </>
        )}
      </main>
      <footer className="footbar">
        <div className="footbar-inner">
          <button className="btn" onClick={() => go(idx - 1)} disabled={idx === 0} aria-label="前の問題">
            <Icon name="back" />
            前へ
          </button>
          {s.mode === 'single' ? (
            <button className="btn primary" onClick={() => history.back()}>閉じる</button>
          ) : isLast && !review ? (
            <button className="btn primary" onClick={() => void finish()} disabled={!s.isExam && !reveal}>
              {s.isExam ? '採点する' : '結果を見る'}
            </button>
          ) : isLast && review ? (
            <button className="btn primary" onClick={() => navigate(`/r/${s.id}`)}>結果に戻る</button>
          ) : (
            <button className={`btn${reveal || examRunning ? ' primary' : ''}`} onClick={() => go(idx + 1)} aria-label="次の問題">
              {reveal && !review ? '次の問題' : '次へ'}
              <Icon name="chev" />
            </button>
          )}
        </div>
      </footer>
      {showSheet && <AnswerSheet s={s} current={idx} onPick={(i) => { setShowSheet(false); go(i); }} onClose={() => setShowSheet(false)} onFinish={() => { setShowSheet(false); void finish(); }} />}
    </>
  );
}

async function autoFinish(id: string) {
  const s = getState().sessions.get(id);
  if (!s || s.finished) return;
  await finishSession(id);
  window.alert('試験時間が終了しました。採点結果を表示します。');
  navigate(`/r/${id}`, { replace: true });
}

function relatedOf(q: Question): Question[] {
  const { qmap, questions } = getState();
  const explicit = (q.relatedQuestionIds ?? []).map((id) => qmap.get(id)).filter(Boolean) as Question[];
  if (explicit.length) return explicit.slice(0, 5);
  if (!q.subcategory) return [];
  return questions.filter((x) => x.id !== q.id && x.subcategory === q.subcategory).slice(0, 3);
}

function Timer({ session, onTimeUp }: { session: Session; onTimeUp: () => void }) {
  const [now, setNow] = useState(Date.now());
  const fired = useRef(false);
  const end = session.startTime + (session.timeLimitMs ?? 0);
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const left = end - now;
  useEffect(() => {
    if (left <= 0 && !fired.current) {
      fired.current = true;
      onTimeUp();
    }
  }, [left, onTimeUp]);
  return <span className={left < 10 * 60 * 1000 ? 'urgent' : ''} aria-label={`残り時間 ${formatDuration(left)}`}>残り {formatDuration(left)}</span>;
}

function AnswerSheet({ s, current, onPick, onClose, onFinish }: { s: Session; current: number; onPick: (i: number) => void; onClose: () => void; onFinish: () => void }) {
  const answered = useMemo(() => s.questionIds.filter((id) => s.answers[id]).length, [s]);
  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="sheet" role="dialog" aria-modal="true" aria-label="解答一覧" onClick={(e) => e.stopPropagation()}>
        <div className="sheet-head">
          <h2>解答一覧 <span className="muted small num">{answered} / {s.questionIds.length} 解答済み</span></h2>
          <button className="icon-btn" onClick={onClose}>閉じる</button>
        </div>
        <div className="sheet-grid">
          {s.questionIds.map((id, i) => {
            const a = s.answers[id];
            return (
              <button key={id} className={`${a ? 'answered' : ''}${i === current ? ' current' : ''}`} onClick={() => onPick(i)} aria-label={`問${i + 1} ${a ? `解答 ${a}` : '未解答'}`}>
                <span className="num">{i + 1}</span>
                <span className="a">{a ? '①②③④'[a - 1] : ''}</span>
              </button>
            );
          })}
        </div>
        <div className="spacer" />
        <button className="btn primary block" onClick={onFinish}>模試を終了して採点する</button>
      </div>
    </div>
  );
}
