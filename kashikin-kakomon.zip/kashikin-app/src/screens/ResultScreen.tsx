import { useStore } from '../lib/store';
import { choiceMark, fmtRate, TENTATIVE_THRESHOLD } from '../lib/logic';
import { startCategory, startIds } from '../lib/start';
import { navigate } from '../router';
import { Group, HomeButton, SmallMark, TopBar, formatDuration } from '../components/ui';
import { questionLabel } from '../components/QuestionParts';

export function ResultScreen({ id }: { id: string }) {
  const st = useStore();
  const s = st.sessions.get(id);
  if (!s || !s.result) {
    return (
      <div className="page center-msg">
        <div>
          <p>結果が見つかりません。</p>
          <button className="btn" onClick={() => navigate('/')}>ホームへ</button>
        </div>
      </div>
    );
  }
  const r = s.result;
  const wrongIds = s.questionIds.filter((qid) => {
    const q = st.qmap.get(qid);
    return q && s.answers[qid] !== q.correctAnswer;
  });
  const cats = [...r.byCategory].sort((a, b) => a.rate - b.rate);
  const weakest = cats.find((c) => c.total > 0 && c.rate < 100);
  const elapsed = (s.endTime ?? Date.now()) - s.startTime;

  return (
    <>
      <TopBar left={<HomeButton />} title="結果" sub={s.title} />
      <main className="page with-header">
        <section className="score-card" aria-label="得点">
          <div>
            <div className="score-main num">
              {r.correct}
              <small> / {r.total}問正解</small>
            </div>
            <div className="score-sub">
              正答率 <b className="num">{fmtRate(r.rate)}</b>　不正解 {r.wrong}問{r.unanswered ? `　未解答 ${r.unanswered}問` : ''}
              <br />
              {s.passingScore != null ? (
                <>
                  合格基準 <b className="num">{s.passingScore}問</b>
                  {s.passingScoreLabel ? `（${s.passingScoreLabel}）` : ''}
                </>
              ) : (
                <span className="muted">{s.isExam ? '合格基準点が確定できないため合否判定なし' : '学習モードのため合否判定なし'}</span>
              )}
              <br />
              <span className="muted">所要時間 {formatDuration(elapsed)}</span>
            </div>
          </div>
          {r.passed != null && (
            <div className={`seal ${r.passed ? 'pass' : 'fail'}`} role="img" aria-label={r.passed ? '合格' : '不合格'}>
              <span>
                {r.passed ? '合格' : '不合格'}
                <small className="num">{r.passed ? `+${r.correct - (s.passingScore ?? 0)}` : `あと${(s.passingScore ?? 0) - r.correct}問`}</small>
              </span>
            </div>
          )}
        </section>

        <Group title="分野別正答率">
          <div className="bars">
            {cats.map((c) => (
              <div className="bar-row" key={c.category}>
                <span>{c.category}{c.total < TENTATIVE_THRESHOLD && <span className="muted small">（参考値）</span>}</span>
                <span className="num">{c.correct}/{c.total}　{fmtRate(c.rate)}</span>
                <span className="track" aria-hidden="true">
                  <span className={`fill${c.rate < 50 ? ' low' : c.rate < 70 ? ' mid' : ''}`} style={{ width: `${c.rate}%`, display: 'block' }} />
                </span>
              </div>
            ))}
          </div>
        </Group>

        {weakest && (
          <div className="weak-callout">
            <p>
              最も弱い分野は <b>{weakest.category}</b>（正答率 {fmtRate(weakest.rate)}、間違い {weakest.total - weakest.correct}問）。{weakest.category}を優先して復習しましょう。
            </p>
            <div className="row-actions">
              <button className="btn small" onClick={() => void startCategory(weakest.category, 10)}>弱点分野を復習</button>
            </div>
          </div>
        )}

        <div className="spacer" />
        <div className="row-actions">
          <button className="btn primary" disabled={!wrongIds.length} onClick={() => void startIds(wrongIds, '間違えた問題の復習')}>
            間違えた問題を復習（{wrongIds.length}問）
          </button>
        </div>

        <Group title="全問題の確認">
          <div className="result-list">
            {s.questionIds.map((qid, i) => {
              const q = st.qmap.get(qid);
              const a = s.answers[qid];
              const ok = q ? (a ? a === q.correctAnswer : null) : null;
              return (
                <a key={qid} className="row" href={`#/s/${s.id}?i=${i}`} aria-label={`問${i + 1}の解説を開く`}>
                  <SmallMark ok={ok} />
                  <span className="grow">
                    <span className="title num">問{i + 1}</span>
                    <span className="desc">
                      {q ? `${questionLabel(q)}・${q.category}` : '削除された問題'}
                    </span>
                  </span>
                  <span className="val num">
                    {a ? choiceMark(a) : '－'} / 正答 {q ? choiceMark(q.correctAnswer) : '－'}
                  </span>
                </a>
              );
            })}
          </div>
        </Group>
        <div className="spacer" />
        <button className="btn block" onClick={() => navigate('/')}>ホームへ</button>
      </main>
    </>
  );
}
