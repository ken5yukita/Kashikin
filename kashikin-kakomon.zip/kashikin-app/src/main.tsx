import { createRoot } from 'react-dom/client';
import { App } from './App';
import { applyTheme, init } from './lib/store';
import './styles.css';

createRoot(document.getElementById('root')!).render(<App />);
void init();

// システムのダーク／ライト切替に追従
matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', () => applyTheme());

// オフライン用 Service Worker（開発サーバーでは登録しない）
if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  });
}
