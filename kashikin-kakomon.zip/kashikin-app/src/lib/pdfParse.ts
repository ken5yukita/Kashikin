/**
 * 公式「試験問題用紙」「正答」PDFから抽出したテキストを問題データへ構造化する（純粋関数）。
 * 方針：
 * - 改行・ヘッダー・ページ番号・制御文字は除去するが、語句の補完や修正は一切しない
 * - 判読不能文字（�・私用領域文字）や選択肢数の異常は issues に記録し、verified は付けない
 * - 注釈（※・（注））は本文に混ぜず annotations に分離。位置不明のため anchorText は null
 */
import type { Annotation, Category, Choice, ChoiceId, SubItem } from '../types';
import { toHalfWidth } from '../data/exams';

export interface PageLines {
  page: number; // 1始まり
  lines: string[];
}

export interface ParsedQuestion {
  seq: number;
  markerNumber: number | null;
  questionText: string;
  items: SubItem[];
  choices: Choice[];
  annotations: Annotation[];
  pages: number[];
  issues: string[];
  guessedCategory: Category;
}

export interface ParsedPaper {
  questions: ParsedQuestion[];
  warnings: string[];
}

const CHOICE_MARKS = ['①', '②', '③', '④'] as const;
const CONTROL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F​﻿]/g;
const UNREADABLE = /[�-]/;
const CJK = '　-ヿ㐀-鿿豈-﫿＀-￯①-⑳「」『』（）【】、。・〜';

/** ヘッダー・フッター・ページ番号など、本文でない行 */
export function isNoiseLine(line: string): boolean {
  const t = line.trim();
  if (!t) return true;
  if (/^DKI[A-Z]?-?\d*\.smd/i.test(t)) return true;
  if (/Page\s+\d+\s+\d{2}\/\d{2}\/\d{2}/.test(t)) return true;
  // ページ番号（「−2−」「- 2 -」「2」。記号が判読不能文字になっている場合も含む）
  const bare = t.replace(/[\uE000-\uF8FF\uFFFD\s−\-－–—‐ー]/g, '');
  if (/^[0-9０-９]{1,3}$/.test(bare) && t.length <= 12) return true;
  if (/^[−\-－–—‐]\s*[\uFFFD\uE000-\uF8FF0-9０-９]{1,3}\s*[−\-－–—‐]$/.test(t)) return true;
  if (/^受\s*験\s*番\s*号$/.test(t)) return true;
  // 問題用紙末尾の「（以上）」
  if (/^[（(]\s*以\s*上\s*[）)]$/.test(t)) return true;
  return false;
}

/** 行内の体裁上の空白を整理（CJK文字に隣接する半角空白のみ除去。意味は変えない） */
/** 康熙部首・CJK部首補助の文字（PDFのフォント都合で「⽇」「⾯」等になるもの）を通常の漢字へ。字形は同一で意味は変わらない */
export function normalizeRadicals(s: string): string {
  return s.replace(/[\u2F00-\u2FDF\u2E80-\u2EFF]/g, (c) => c.normalize('NFKC'));
}

export function tidySpaces(s: string): string {
  let t = normalizeRadicals(s.replace(CONTROL, '')).replace(/[ \t]+/g, ' ');
  const re = new RegExp(`(?<=[${CJK}])[ ]+|[ ]+(?=[${CJK}])`, 'g');
  t = t.replace(re, '');
  return t.trim();
}

function joinLines(parts: string[]): string {
  let out = '';
  for (const raw of parts) {
    const p = tidySpaces(raw);
    if (!p) continue;
    if (out && /[A-Za-z0-9]$/.test(out) && /^[A-Za-z0-9]/.test(p)) out += ' ';
    out += p;
  }
  return out;
}

const Q_START = /^【\s*問\s*題\s*([0-9０-９�]*)\s*】\s*(.*)$/;
const SUBITEM = /^([ａ-ｅa-eア-オ])[\s　]+(.*)$/;
const ANNOT = /^(※|（注[0-9０-９]*）|\(注[0-9０-９]*\)|注[0-9０-９]*[：:])(.*)$/;

type Seg = { kind: 'stem' } | { kind: 'item'; label: string } | { kind: 'choice'; idx: number } | { kind: 'annot' };

/** 「① 2個 ② 3個 …」のように1行に複数の選択肢がある場合、期待順の記号でのみ分割 */
function splitChoiceLine(line: string, startIdx: number): Array<{ idx: number; text: string }> {
  const out: Array<{ idx: number; text: string }> = [];
  let rest = line.trim().slice(1);
  let idx = startIdx;
  for (;;) {
    const next = CHOICE_MARKS[idx + 1];
    const pos = next ? rest.indexOf(next) : -1;
    if (pos === -1) {
      out.push({ idx, text: rest });
      break;
    }
    out.push({ idx, text: rest.slice(0, pos) });
    rest = rest.slice(pos + 1);
    idx++;
  }
  return out;
}

export function guessCategory(text: string): Category {
  const t = text;
  const has = (...w: string[]) => w.some((x) => t.includes(x));
  if (has('犯罪による収益の移転防止', '犯罪収益移転防止', '取引時確認')) return '犯罪収益移転防止法';
  if (has('個人情報', '個人データ', '個人信用情報')) return '個人情報保護';
  if (has('貸借対照表', '損益計算書', '財務諸表', '企業会計原則', 'キャッシュ・フロー', '簿記', '会計', '家計')) return '財務・会計';
  if (has('利息制限法', '営業的金銭消費貸借の特則', 'みなし利息')) return '利息制限法';
  if (has('出資の受入れ', '出資法')) return '出資法';
  if (has('民事訴訟', '民事執行', '民事保全', '破産', '民事再生', '支払督促', '強制執行', '少額訴訟', '手形訴訟')) return '民事手続';
  if (has('消費者契約法', '不当景品', '景品表示', '紛争解決', '苦情処理', '広告', '勧誘', '貸付自粛', '資金需要者等の利益の保護')) return '資金需要者保護';
  if (has('会社法', '商法', '手形法', '小切手法', '商行為')) return '商法';
  if (has('民法', '時効', '相殺', '保証', '抵当権', '債権譲渡', '意思表示', '代理', '相続', '弁済', '契約の解除', '消費貸借')) {
    if (has('貸金業法', '貸金業者', '貸金業務取扱主任者')) return '貸金業法';
    return '民法';
  }
  if (has('貸金業法', '貸金業者', '貸金業務取扱主任者', '貸金業協会', '指定信用情報機関')) return '貸金業法';
  return 'その他関連法令';
}

export function parsePaper(pages: PageLines[]): ParsedPaper {
  const warnings: string[] = [];
  const blocks: Array<{ marker: string; first: string; lines: Array<{ text: string; page: number }> }> = [];
  let cur: (typeof blocks)[number] | null = null;
  for (const pg of pages) {
    for (const rawLine of pg.lines) {
      if (isNoiseLine(rawLine)) continue;
      const line = rawLine.replace(CONTROL, '').trim();
      const m = line.match(Q_START);
      if (m) {
        cur = { marker: m[1], first: m[2], lines: [] };
        cur.lines.push({ text: m[2], page: pg.page });
        blocks.push(cur);
        continue;
      }
      if (cur) cur.lines.push({ text: line, page: pg.page });
    }
  }

  const questions: ParsedQuestion[] = blocks.map((b, i) => {
    const seq = i + 1;
    const issues: string[] = [];
    const markerHalf = toHalfWidth(b.marker);
    const markerNumber = /^\d+$/.test(markerHalf) ? Number(markerHalf) : null;
    if (markerNumber == null) issues.push('問題番号を判読できないため、出現順で番号を付けました');
    else if (markerNumber !== seq) issues.push(`問題番号（${markerNumber}）と出現順（${seq}）が一致しません`);

    const stem: string[] = [];
    const items: Array<{ label: string; parts: string[] }> = [];
    const choices: string[][] = [[], [], [], []];
    const annots: string[][] = [];
    const pagesSet = new Set<number>();
    let seg: Seg = { kind: 'stem' };
    let nextChoice = 0;

    for (const { text, page } of b.lines) {
      if (!text) continue;
      pagesSet.add(page);
      const t = text.trim();
      // 「①〜④の中から」のように行頭に来た指示文は選択肢として扱わない
      const isRangeRef = /^①\s*(?:[〜～~ー－\-]|から)\s*④?/.test(t);
      if (nextChoice < 4 && t.startsWith(CHOICE_MARKS[nextChoice]) && !isRangeRef) {
        for (const part of splitChoiceLine(t, nextChoice)) {
          choices[part.idx].push(part.text);
          nextChoice = part.idx + 1;
          seg = { kind: 'choice', idx: part.idx };
        }
        continue;
      }
      const am = t.match(ANNOT);
      if (am) {
        annots.push([t]);
        seg = { kind: 'annot' };
        continue;
      }
      // 小問は選択肢が始まる前のみ
      const sm = nextChoice === 0 ? t.match(SUBITEM) : null;
      if (sm && (items.length > 0 || seg.kind === 'stem') && isNextLabel(items.map((x) => x.label), sm[1])) {
        items.push({ label: sm[1], parts: [sm[2]] });
        seg = { kind: 'item', label: sm[1] };
        continue;
      }
      if (seg.kind === 'stem') stem.push(t);
      else if (seg.kind === 'item') items[items.length - 1].parts.push(t);
      else if (seg.kind === 'choice') choices[seg.idx].push(t);
      else annots[annots.length - 1].push(t);
    }

    const questionText = joinLines(stem);
    const outChoices: Choice[] = choices.map((parts, idx) => ({ id: (idx + 1) as ChoiceId, text: joinLines(parts) }));
    const outItems: SubItem[] = items.map((it) => ({ label: it.label, text: joinLines(it.parts) }));
    const annotations: Annotation[] = annots.map((a) => ({ text: joinLines(a), anchorText: null }));

    if (!questionText) issues.push('問題文を抽出できませんでした');
    const filled = outChoices.filter((c) => c.text).length;
    if (filled !== 4) issues.push(`選択肢を${filled}個しか分離できませんでした（4個必要）`);
    const all = [questionText, ...outItems.map((x) => x.text), ...outChoices.map((c) => c.text)].join('');
    if (UNREADABLE.test(all)) issues.push('判読不能な文字（�）があります。原本で数字等を確認してください');
    if (annotations.length) issues.push('注釈があります。本文との位置関係を原本で確認してください');

    return {
      seq,
      markerNumber,
      questionText,
      items: outItems,
      choices: outChoices,
      annotations,
      pages: [...pagesSet].sort((a, c) => a - c),
      issues,
      guessedCategory: guessCategory(questionText + outItems.map((x) => x.text).join('')),
    };
  });

  if (!questions.length) warnings.push('「【問題】」の見出しが見つかりませんでした。試験問題用紙のPDFか確認してください');
  else if (questions.length !== 50) warnings.push(`検出した問題数が${questions.length}問です（通常は50問）`);
  return { questions, warnings };
}

function isNextLabel(existing: string[], label: string): boolean {
  const seqs = ['ａｂｃｄｅ', 'abcde', 'アイウエオ'];
  for (const s of seqs) {
    if (!s.includes(label)) continue;
    const expected = s[existing.length];
    return existing.every((l) => s.includes(l)) && label === expected;
  }
  return false;
}

// ===== 正答PDF =====

export interface ParsedAnswers {
  answers: Map<number, ChoiceId>;
  warnings: string[];
}

export function parseAnswerKey(text: string): ParsedAnswers {
  const warnings: string[] = [];
  const answers = new Map<number, ChoiceId>();
  const t = toHalfWidth(text.normalize('NFC'));
  const re = /問\s*題\s*(\d{1,2})\s*([①②③④])/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(t))) {
    const n = Number(m[1]);
    const c = (CHOICE_MARKS.indexOf(m[2] as (typeof CHOICE_MARKS)[number]) + 1) as ChoiceId;
    if (answers.has(n) && answers.get(n) !== c) warnings.push(`問題${n}の正答が複数あります`);
    answers.set(n, c);
  }
  const max = Math.max(0, ...answers.keys());
  const missing: number[] = [];
  for (let i = 1; i <= Math.max(50, max); i++) if (!answers.has(i)) missing.push(i);
  if (!answers.size) warnings.push('正答を読み取れませんでした');
  else if (missing.length) warnings.push(`正答を読み取れなかった問題：${missing.join('、')}`);
  return { answers, warnings };
}

export type PdfKind = 'paper' | 'answer' | 'unknown';

export function detectKind(fileName: string, text: string): PdfKind {
  const f = fileName.toLowerCase();
  if (f.includes('answer')) return 'answer';
  if (f.includes('exam_paper') || f.includes('paper')) return 'paper';
  if (/【\s*問\s*題/.test(text)) return 'paper';
  const hits = (toHalfWidth(text).match(/問\s*題\s*\d{1,2}\s*[①②③④]/g) ?? []).length;
  if (hits >= 10 || /正\s*答/.test(text)) return 'answer';
  return 'unknown';
}
