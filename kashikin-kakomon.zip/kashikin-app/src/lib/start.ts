import type { Category, Question, SessionMode } from '../types';
import { getExam, referencePassingScore } from '../data/exams';
import { categorySummaries, selectQuestions, selectToday, weakRanking } from './logic';
import { createSession, getState, mockPool, selectContext, showToast, studyPool } from './store';
import { navigate } from '../router';

const MOCK_MS = 120 * 60 * 1000;

async function launch(mode: SessionMode, title: string, qs: Question[], extra: Partial<Parameters<typeof createSession>[0]> = {}) {
  if (!qs.length) {
    showToast('出題できる問題がありません');
    return;
  }
  const id = await createSession({ mode, title, questionIds: qs.map((q) => q.id), ...extra });
  navigate(`/s/${id}`);
}

export function startRandom(n: number) {
  return launch('random', `ランダム${n}問`, selectQuestions(studyPool(), n, selectContext()));
}

export function startMock() {
  const pool = mockPool();
  if (pool.length < 50) {
    const ok = window.confirm(`模試に使える問題が${pool.length}問しかありません（50問必要）。${pool.length}問で開始しますか？\n※未検証の問題を含めるには設定を変更してください。`);
    if (!ok) return;
  }
  const ref = referencePassingScore();
  return launch('mock', '模擬試験', selectQuestions(pool, 50, selectContext()), {
    isExam: true,
    timeLimitMs: MOCK_MS,
    passingScore: pool.length >= 50 ? ref.score : null,
    passingScoreLabel: pool.length >= 50 ? ref.label : null,
  });
}

export function startExam(examId: string, asMock: boolean) {
  const exam = getExam(examId);
  const all = getState().questions.filter((q) => q.examId === examId);
  const pool = asMock && !getState().settings.includeUnverifiedInMock ? all.filter((q) => q.verified) : all;
  if (asMock && pool.length < all.length) {
    const ok = window.confirm(`この回の未検証問題${all.length - pool.length}問を除いた${pool.length}問で本番形式を開始しますか？\n（設定で未検証問題を模試に含めることもできます）`);
    if (!ok) return;
  }
  const qs = [...pool].sort((a, b) => a.questionNumber - b.questionNumber);
  const full = qs.length === (exam?.questionCount ?? 50);
  const label = exam?.round ? `第${exam.round}回` : exam?.examName ?? examId;
  return launch(asMock ? 'exam-mock' : 'exam-study', asMock ? `${label} 本番形式` : `${label} 過去問`, qs, {
    isExam: asMock,
    timeLimitMs: asMock ? MOCK_MS : null,
    examId,
    passingScore: asMock && full ? exam?.passingScore ?? null : null,
    passingScoreLabel: asMock && full && exam?.passingScore != null ? `第${exam.round}回の合格基準点` : null,
  });
}

export function startCategory(cat: Category, n: number) {
  const pool = studyPool().filter((q) => q.category === cat);
  return launch('category', `${cat}`, selectQuestions(pool, n, selectContext()));
}

export function startUnanswered(n: number) {
  const { progress } = getState();
  const pool = studyPool().filter((q) => !progress.get(q.id)?.attemptCount);
  return launch('unanswered', '未出題のみ', selectQuestions(pool, n, selectContext()));
}

export function wrongQuestions(): Question[] {
  const { progress } = getState();
  return studyPool().filter((q) => progress.get(q.id)?.lastCorrect === false);
}

export function startWrong(n = 9999) {
  return launch('wrong', '間違えた問題', selectQuestions(wrongQuestions(), n, selectContext()));
}

export function startBookmarks() {
  const { bookmarks, qmap } = getState();
  const qs = [...bookmarks.values()].sort((a, b) => a.createdAt - b.createdAt).map((b) => qmap.get(b.questionId)).filter(Boolean) as Question[];
  return launch('bookmark', 'ブックマーク', selectQuestions(qs, qs.length, selectContext()));
}

export function startWeak(n: number) {
  const { questions, progress } = getState();
  const ranking = weakRanking(categorySummaries(questions, progress)).slice(0, 2).map((s) => s.category);
  if (!ranking.length) {
    showToast('まだ弱点を判定できるだけの回答がありません');
    return;
  }
  const pool = studyPool().filter((q) => ranking.includes(q.category));
  return launch('weak', `弱点：${ranking.join('・')}`, selectQuestions(pool, n, selectContext()));
}

export function startToday() {
  const { settings } = getState();
  return launch('today', '今日の学習', selectToday(studyPool(), settings.dailyGoal, selectContext()));
}

export function startIds(ids: string[], title: string, mode: SessionMode = 'retry') {
  const { qmap } = getState();
  const qs = ids.map((id) => qmap.get(id)).filter(Boolean) as Question[];
  return launch(mode, title, qs);
}

export async function openSingle(qid: string) {
  const q = getState().qmap.get(qid);
  if (!q) {
    showToast('問題が見つかりません');
    navigate('/', { replace: true });
    return;
  }
  const id = await createSession({ mode: 'single', title: '1問', questionIds: [qid] });
  navigate(`/s/${id}`, { replace: true });
}
