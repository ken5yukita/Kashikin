import { useSyncExternalStore } from 'react';
import {
  DEFAULT_META,
  DEFAULT_SETTINGS,
  type AnswerLog,
  type ChoiceId,
  type Meta,
  type Progress,
  type Question,
  type Session,
  type SessionMode,
  type Settings,
} from '../types';
import * as db from './db';
import type { Bookmark } from './db';
import { applyAnswer, categorySummaries, isCycleComplete, scoreSession, searchText, weakCategorySet } from './logic';
import { validateQuestion } from './validate';

export interface InvalidQuestion {
  id: string;
  errors: string[];
}

export interface State {
  ready: boolean;
  fatal: string | null;
  questions: Question[];
  qmap: Map<string, Question>;
  invalid: InvalidQuestion[];
  progress: Map<string, Progress>;
  bookmarks: Map<string, Bookmark>;
  logs: AnswerLog[];
  sessions: Map<string, Session>;
  settings: Settings;
  meta: Meta;
  toast: string | null;
  bundleWarnings: string[];
}

let state: State = {
  ready: false,
  fatal: null,
  questions: [],
  qmap: new Map(),
  invalid: [],
  progress: new Map(),
  bookmarks: new Map(),
  logs: [],
  sessions: new Map(),
  settings: DEFAULT_SETTINGS,
  meta: DEFAULT_META,
  toast: null,
  bundleWarnings: [],
};

const listeners = new Set<() => void>();
function set(patch: Partial<State>) {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
}
export function getState() {
  return state;
}
export function useStore(): State {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => state,
  );
}

let searchIndex: Map<string, string> | null = null;
export function getSearchIndex(): Map<string, string> {
  if (!searchIndex) searchIndex = new Map(state.questions.map((q) => [q.id, searchText(q)]));
  return searchIndex;
}

function setQuestions(all: Question[]) {
  const valid: Question[] = [];
  const invalid: InvalidQuestion[] = [];
  for (const q of all) {
    try {
      const r = validateQuestion(q);
      if (r.ok) valid.push(q);
      else invalid.push({ id: (q as Question)?.id ?? '(id不明)', errors: r.errors });
    } catch (e) {
      invalid.push({ id: (q as Question)?.id ?? '(id不明)', errors: [String(e)] });
    }
  }
  valid.sort((a, b) => a.examId.localeCompare(b.examId) || a.questionNumber - b.questionNumber);
  searchIndex = null;
  set({ questions: valid, qmap: new Map(valid.map((q) => [q.id, q])), invalid });
}

// ===== 初期化 =====

async function loadBundled(): Promise<string[]> {
  const warnings: string[] = [];
  try {
    const res = await fetch('data/index.json', { cache: 'no-cache' });
    if (!res.ok) throw new Error(`index.json: ${res.status}`);
    const index = (await res.json()) as { files: string[] };
    for (const file of index.files) {
      try {
        const r = await fetch(`data/${file}`, { cache: 'no-cache' });
        if (!r.ok) throw new Error(String(r.status));
        const data = (await r.json()) as { version?: string; questions: Question[] };
        const key = `bundle:${file}`;
        const prev = await db.kv.get<string>(key);
        const version = data.version ?? JSON.stringify(data).length.toString();
        if (prev === version) continue;
        const now = Date.now();
        await db.putMany('questions', data.questions.map((q) => ({ ...q, updatedAt: now })));
        await db.kv.set(key, version);
      } catch (e) {
        warnings.push(`同梱データ ${file} を読み込めませんでした（${String(e)}）`);
      }
    }
  } catch {
    // オフラインかつ未キャッシュ：IndexedDBの既存データで続行
  }
  return warnings;
}

export async function init() {
  try {
    await db.openDB();
    const bundleWarnings = await loadBundled();
    const [questions, progress, bookmarks, logs, sessions, settings, meta] = await Promise.all([
      db.getAll<Question>('questions'),
      db.getAll<Progress>('progress'),
      db.getAll<Bookmark>('bookmarks'),
      db.getAll<AnswerLog>('answers'),
      db.getAll<Session>('sessions'),
      db.kv.get<Settings>('settings'),
      db.kv.get<Meta>('meta'),
    ]);
    setQuestions(questions);
    set({
      progress: new Map(progress.map((p) => [p.questionId, p])),
      bookmarks: new Map(bookmarks.map((b) => [b.questionId, b])),
      logs: logs.sort((a, b) => a.answeredAt - b.answeredAt),
      sessions: new Map(sessions.map((s) => [s.id, s])),
      settings: { ...DEFAULT_SETTINGS, ...(settings ?? {}) },
      meta: { ...DEFAULT_META, ...(meta ?? {}) },
      bundleWarnings,
      ready: true,
    });
    applyTheme();
    if (navigator.storage?.persist) navigator.storage.persist().catch(() => {});
  } catch (e) {
    set({ fatal: `データベースを開けませんでした：${String(e)}`, ready: true });
  }
}

// ===== 設定 =====

export function applyTheme() {
  const { theme, fontSize } = state.settings;
  const el = document.documentElement;
  if (theme === 'system') delete el.dataset.theme;
  else el.dataset.theme = theme;
  el.dataset.font = fontSize;
  const dark = theme === 'dark' || (theme === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', dark ? '#121417' : '#f6f5f1');
}

export async function updateSettings(patch: Partial<Settings>) {
  const settings = { ...state.settings, ...patch };
  set({ settings });
  applyTheme();
  await db.kv.set('settings', settings);
}

export function showToast(msg: string) {
  set({ toast: msg });
  setTimeout(() => {
    if (state.toast === msg) set({ toast: null });
  }, 2800);
}

// ===== 出題対象 =====

export function studyPool(): Question[] {
  return state.settings.includeUnverifiedInStudy ? state.questions : state.questions.filter((q) => q.verified);
}
export function mockPool(): Question[] {
  return state.settings.includeUnverifiedInMock ? state.questions : state.questions.filter((q) => q.verified);
}
export function selectContext() {
  return {
    progress: state.progress,
    cycle: state.meta.currentCycle,
    now: Date.now(),
    weakCategories: weakCategorySet(categorySummaries(state.questions, state.progress)),
  };
}

// ===== セッション =====

export interface NewSessionOptions {
  mode: SessionMode;
  title: string;
  questionIds: string[];
  isExam?: boolean;
  timeLimitMs?: number | null;
  examId?: string | null;
  passingScore?: number | null;
  passingScoreLabel?: string | null;
}

export async function createSession(o: NewSessionOptions): Promise<string> {
  const ids = [...new Set(o.questionIds)]; // 念のため重複を排除
  const id = `s-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
  const s: Session = {
    id,
    mode: o.mode,
    title: o.title,
    questionIds: ids,
    answers: {},
    locked: {},
    currentIndex: 0,
    startTime: Date.now(),
    endTime: null,
    timeLimitMs: o.timeLimitMs ?? null,
    isExam: !!o.isExam,
    examId: o.examId ?? null,
    passingScore: o.passingScore ?? null,
    passingScoreLabel: o.passingScoreLabel ?? null,
    finished: false,
  };
  await saveSession(s);
  return id;
}

async function saveSession(s: Session) {
  const sessions = new Map(state.sessions);
  sessions.set(s.id, s);
  set({ sessions });
  await db.put('sessions', s);
}

export function unfinishedSession(): Session | null {
  let best: Session | null = null;
  for (const s of state.sessions.values()) {
    if (s.finished || s.mode === 'single') continue;
    if (!best || s.startTime > best.startTime) best = s;
  }
  return best;
}

export async function setIndex(sessionId: string, idx: number) {
  const s = state.sessions.get(sessionId);
  if (!s || s.currentIndex === idx) return;
  await saveSession({ ...s, currentIndex: idx });
}

async function recordAnswer(s: Session, q: Question, choice: ChoiceId, now: number) {
  const correct = choice === q.correctAnswer;
  const p = applyAnswer(state.progress.get(q.id), q.id, choice, correct, now, state.meta.currentCycle);
  const log: AnswerLog = {
    questionId: q.id,
    selected: choice,
    correct,
    answeredAt: now,
    sessionId: s.id,
    mode: s.mode,
    category: q.category,
  };
  const id = await db.saveAnswer(p, log);
  const progress = new Map(state.progress);
  progress.set(q.id, p);
  set({ progress, logs: [...state.logs, { ...log, id }] });
}

async function checkCycle() {
  const pool = studyPool();
  if (isCycleComplete(pool, state.progress, state.meta.currentCycle)) {
    const meta: Meta = {
      currentCycle: state.meta.currentCycle + 1,
      cycleCompletedAt: [...state.meta.cycleCompletedAt, Date.now()],
    };
    set({ meta });
    await db.kv.set('meta', meta);
    showToast(`全問題を1周しました（${meta.cycleCompletedAt.length}周目完了）`);
  }
}

/** 回答。学習モードは確定（変更不可）して即記録、模試は変更可で終了時に記録 */
export async function answer(sessionId: string, questionId: string, choice: ChoiceId) {
  const s = state.sessions.get(sessionId);
  const q = state.qmap.get(questionId);
  if (!s || !q || s.finished) return;
  if (s.isExam) {
    await saveSession({ ...s, answers: { ...s.answers, [questionId]: choice } });
    return;
  }
  if (s.locked[questionId]) return;
  await saveSession({
    ...s,
    answers: { ...s.answers, [questionId]: choice },
    locked: { ...s.locked, [questionId]: true },
  });
  await recordAnswer(s, q, choice, Date.now());
  await checkCycle();
}

export async function finishSession(sessionId: string) {
  const s = state.sessions.get(sessionId);
  if (!s || s.finished) return;
  const now = Date.now();
  if (s.isExam) {
    for (const id of s.questionIds) {
      const q = state.qmap.get(id);
      const a = s.answers[id];
      if (q && a) await recordAnswer(s, q, a, now);
    }
  }
  const result = scoreSession(s, state.qmap, now);
  await saveSession({ ...s, finished: true, endTime: now, result });
  if (s.isExam) await checkCycle();
}

export async function deleteSession(sessionId: string) {
  const sessions = new Map(state.sessions);
  sessions.delete(sessionId);
  set({ sessions });
  await db.del('sessions', sessionId);
}

// ===== ブックマーク =====

export async function toggleBookmark(questionId: string) {
  const bookmarks = new Map(state.bookmarks);
  if (bookmarks.has(questionId)) {
    bookmarks.delete(questionId);
    set({ bookmarks });
    await db.del('bookmarks', questionId);
  } else {
    const b = { questionId, createdAt: Date.now() };
    bookmarks.set(questionId, b);
    set({ bookmarks });
    await db.put('bookmarks', b);
  }
}

// ===== 問題データの登録・更新 =====

export async function saveQuestions(list: Question[]) {
  const now = Date.now();
  const stamped = list.map((q) => ({ ...q, updatedAt: now }));
  await db.putMany('questions', stamped);
  setQuestions(await db.getAll<Question>('questions'));
}

export async function deleteQuestions(ids: string[]) {
  await db.delMany('questions', ids);
  setQuestions(await db.getAll<Question>('questions'));
}

export async function setVerified(ids: string[], verified: boolean) {
  const list = ids.map((id) => state.qmap.get(id)).filter(Boolean) as Question[];
  await saveQuestions(list.map((q) => ({ ...q, verified })));
}

// ===== リセット・バックアップ =====

export async function resetLearning() {
  await db.clear(['progress', 'answers', 'bookmarks', 'sessions']);
  await db.kv.set('meta', DEFAULT_META);
  set({ progress: new Map(), logs: [], bookmarks: new Map(), sessions: new Map(), meta: DEFAULT_META });
}

export const BACKUP_FORMAT = 'kashikin-kakomon-backup';

export function buildBackup() {
  return {
    format: BACKUP_FORMAT,
    version: 1,
    exportedAt: new Date().toISOString(),
    note: '学習データのみ（問題データは含みません）',
    settings: state.settings,
    meta: state.meta,
    progress: [...state.progress.values()],
    answers: state.logs.map(({ id: _id, ...rest }) => rest),
    bookmarks: [...state.bookmarks.values()],
    sessions: [...state.sessions.values()],
  };
}

export async function restoreBackup(data: unknown): Promise<string> {
  const d = data as ReturnType<typeof buildBackup>;
  if (!d || d.format !== BACKUP_FORMAT) throw new Error('このアプリの学習データバックアップではありません');
  if (!Array.isArray(d.progress) || !Array.isArray(d.answers)) throw new Error('バックアップの形式が不正です');
  await db.clear(['progress', 'answers', 'bookmarks', 'sessions']);
  await db.putMany('progress', d.progress);
  await db.putMany('answers', d.answers);
  await db.putMany('bookmarks', d.bookmarks ?? []);
  await db.putMany('sessions', d.sessions ?? []);
  const settings = { ...DEFAULT_SETTINGS, ...(d.settings ?? {}) };
  const meta = { ...DEFAULT_META, ...(d.meta ?? {}) };
  await db.kv.set('settings', settings);
  await db.kv.set('meta', meta);
  const [progress, logs, bookmarks, sessions] = await Promise.all([
    db.getAll<Progress>('progress'),
    db.getAll<AnswerLog>('answers'),
    db.getAll<Bookmark>('bookmarks'),
    db.getAll<Session>('sessions'),
  ]);
  set({
    progress: new Map(progress.map((p) => [p.questionId, p])),
    logs: logs.sort((a, b) => a.answeredAt - b.answeredAt),
    bookmarks: new Map(bookmarks.map((b) => [b.questionId, b])),
    sessions: new Map(sessions.map((s) => [s.id, s])),
    settings,
    meta,
  });
  applyTheme();
  const missing = progress.filter((p) => !state.qmap.has(p.questionId)).length;
  return `復元しました（回答履歴 ${logs.length}件）` + (missing ? `。この端末に問題データがない履歴が${missing}問分あります（問題を取り込むと反映されます）` : '');
}

export const QUESTIONS_FORMAT = 'kashikin-kakomon-questions';

export function buildQuestionsExport(ids?: string[]) {
  const list = ids ? (ids.map((id) => state.qmap.get(id)).filter(Boolean) as Question[]) : state.questions;
  return { format: QUESTIONS_FORMAT, version: 1, exportedAt: new Date().toISOString(), questions: list };
}

/**
 * 問題JSONの取込。
 * - { questions: Question[] }：問題の追加・置換
 * - { explanations: [{ questionId, explanation, legalBasis?, relatedQuestionIds?, subcategory? }] }：既存問題へ解説を統合
 */
export async function importQuestionsJson(data: unknown): Promise<{ added: number; updated: number; rejected: InvalidQuestion[]; explained: number; notFound: string[] }> {
  const d = data as { questions?: Question[]; explanations?: Array<{ questionId: string; explanation: Question['explanation']; legalBasis?: string[]; relatedQuestionIds?: string[]; subcategory?: string }> };
  const rejected: InvalidQuestion[] = [];
  let added = 0;
  let updated = 0;
  const toSave: Question[] = [];
  if (Array.isArray(d?.questions)) {
    for (const q of d.questions) {
      const r = validateQuestion(q);
      if (!r.ok) {
        rejected.push({ id: q?.id ?? '(id不明)', errors: r.errors });
        continue;
      }
      if (state.qmap.has(q.id)) updated++;
      else added++;
      toSave.push({ ...q, importedAt: Date.now() });
    }
  }
  let explained = 0;
  const notFound: string[] = [];
  if (Array.isArray(d?.explanations)) {
    const pending = new Map(toSave.map((q) => [q.id, q]));
    for (const e of d.explanations) {
      const base = pending.get(e.questionId) ?? state.qmap.get(e.questionId);
      if (!base) {
        notFound.push(e.questionId);
        continue;
      }
      const merged: Question = {
        ...base,
        explanation: e.explanation ?? base.explanation,
        legalBasis: e.legalBasis ?? base.legalBasis,
        relatedQuestionIds: e.relatedQuestionIds ?? base.relatedQuestionIds,
        subcategory: e.subcategory ?? base.subcategory,
      };
      const r = validateQuestion(merged);
      if (!r.ok) {
        rejected.push({ id: e.questionId, errors: r.errors });
        continue;
      }
      pending.set(merged.id, merged);
      explained++;
    }
    toSave.splice(0, toSave.length, ...pending.values());
  }
  if (!Array.isArray(d?.questions) && !Array.isArray(d?.explanations)) throw new Error('questions または explanations を含むJSONではありません');
  if (toSave.length) await saveQuestions(toSave);
  return { added, updated, rejected, explained, notFound };
}

export async function downloadJson(name: string, data: unknown) {
  const text = JSON.stringify(data, null, 2);
  // iPhone（特にホーム画面から起動したPWA）では共有シート経由の「ファイルに保存」が確実
  try {
    const file = new File([text], name, { type: 'application/json' });
    if (navigator.canShare?.({ files: [file] })) {
      await navigator.share({ files: [file], title: name });
      return;
    }
  } catch (e) {
    if ((e as DOMException)?.name === 'AbortError') return;
  }
  const blob = new Blob([text], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
