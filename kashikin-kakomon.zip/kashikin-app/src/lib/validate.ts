import { CATEGORIES, type Category, type ChoiceId, type Question } from '../types';

export interface ValidationResult {
  ok: boolean;
  errors: string[];
  /** 表示は可能だが確認が必要な点 */
  warnings: string[];
}

const norm = (s: string) => s.replace(/\s+/g, '').normalize('NFKC');

/** 問題1件の検証。壊れた問題はアプリ全体を止めずに除外する（要件122・123） */
export function validateQuestion(raw: unknown): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  const q = raw as Partial<Question>;
  if (!q || typeof q !== 'object') return { ok: false, errors: ['問題データがオブジェクトではありません'], warnings };
  if (!q.id || typeof q.id !== 'string') errors.push('id がありません');
  if (!q.examId) errors.push('examId がありません');
  if (!q.questionText || typeof q.questionText !== 'string' || !q.questionText.trim()) errors.push('questionText がありません');
  if (!Array.isArray(q.choices) || q.choices.length !== 4) errors.push('choices が4つではありません');
  else {
    q.choices.forEach((c, i) => {
      if (!c || c.id !== ((i + 1) as ChoiceId)) errors.push(`choices[${i}] の id が ${i + 1} ではありません`);
      if (!c || typeof c.text !== 'string' || !c.text.trim()) errors.push(`選択肢${i + 1} の本文がありません`);
    });
  }
  if (![1, 2, 3, 4].includes(q.correctAnswer as number)) errors.push('correctAnswer が1〜4ではありません');
  if (!q.category || !CATEGORIES.includes(q.category as Category)) errors.push(`category「${q.category ?? ''}」が分類一覧にありません`);
  if (typeof q.verified !== 'boolean') errors.push('verified がありません');
  if (!q.sourceType) errors.push('sourceType がありません');

  // 解説の引用が実際の問題文に含まれるか（要件78）
  if (q.explanation && Array.isArray(q.choices)) {
    const pool = [q.questionText ?? '', ...(q.items ?? []).map((i) => i.text), ...q.choices.map((c) => c?.text ?? '')]
      .map(norm)
      .join('\n');
    for (const ce of q.explanation.choices ?? []) {
      if (ce.wrongQuote && !pool.includes(norm(ce.wrongQuote))) warnings.push(`選択肢${ce.id}の引用が問題文と一致しません`);
    }
    for (const it of q.explanation.items ?? []) {
      if (it.wrongQuote && !pool.includes(norm(it.wrongQuote))) warnings.push(`小問${it.label}の引用が問題文と一致しません`);
    }
    if ((q.explanation.choices?.length ?? 0) !== 4) warnings.push('選択肢ごとの解説が4件そろっていません');
  }
  if (/�/.test(JSON.stringify([q.questionText, q.items, q.choices]))) warnings.push('判読不能な文字（�）を含みます');
  return { ok: errors.length === 0, errors, warnings };
}

/** 引用文字列が問題本文に含まれるか（表示時に「引用不一致」を出すため） */
export function quoteMatches(q: Question, quote: string): boolean {
  const pool = [q.questionText, ...(q.items ?? []).map((i) => i.text), ...q.choices.map((c) => c.text)].map(norm).join('\n');
  return pool.includes(norm(quote));
}
