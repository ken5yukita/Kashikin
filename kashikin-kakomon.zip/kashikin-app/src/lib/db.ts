/**
 * IndexedDB の薄いラッパー（外部ライブラリなし）。
 * 問題データ（questions）と学習データ（progress / answers / bookmarks / sessions / kv）は別ストア。
 */
import type { AnswerLog, Progress, Question, Session } from '../types';

const DB_NAME = 'kashikin-kakomon';
const DB_VERSION = 1;

export type StoreName = 'questions' | 'progress' | 'answers' | 'bookmarks' | 'sessions' | 'kv';
export const LEARNING_STORES: StoreName[] = ['progress', 'answers', 'bookmarks', 'sessions'];

export interface Bookmark {
  questionId: string;
  createdAt: number;
}

let dbPromise: Promise<IDBDatabase> | null = null;

export function openDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('questions')) {
        const s = db.createObjectStore('questions', { keyPath: 'id' });
        s.createIndex('examId', 'examId');
      }
      if (!db.objectStoreNames.contains('progress')) db.createObjectStore('progress', { keyPath: 'questionId' });
      if (!db.objectStoreNames.contains('answers')) {
        const s = db.createObjectStore('answers', { keyPath: 'id', autoIncrement: true });
        s.createIndex('questionId', 'questionId');
        s.createIndex('answeredAt', 'answeredAt');
      }
      if (!db.objectStoreNames.contains('bookmarks')) db.createObjectStore('bookmarks', { keyPath: 'questionId' });
      if (!db.objectStoreNames.contains('sessions')) db.createObjectStore('sessions', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('kv')) db.createObjectStore('kv');
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
    req.onblocked = () => reject(new Error('データベースが他のタブで使用中です'));
  });
  return dbPromise;
}

function reqP<T>(r: IDBRequest<T>): Promise<T> {
  return new Promise((res, rej) => {
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}

function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((res, rej) => {
    tx.oncomplete = () => res();
    tx.onerror = () => rej(tx.error);
    tx.onabort = () => rej(tx.error ?? new Error('transaction aborted'));
  });
}

export async function getAll<T>(store: StoreName): Promise<T[]> {
  const db = await openDB();
  return reqP(db.transaction(store).objectStore(store).getAll()) as Promise<T[]>;
}

export async function get<T>(store: StoreName, key: IDBValidKey): Promise<T | undefined> {
  const db = await openDB();
  return reqP(db.transaction(store).objectStore(store).get(key)) as Promise<T | undefined>;
}

export async function put(store: StoreName, value: unknown, key?: IDBValidKey): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(store, 'readwrite');
  tx.objectStore(store).put(value, key);
  await txDone(tx);
}

export async function putMany(store: StoreName, values: unknown[]): Promise<void> {
  if (!values.length) return;
  const db = await openDB();
  const tx = db.transaction(store, 'readwrite');
  const s = tx.objectStore(store);
  for (const v of values) s.put(v);
  await txDone(tx);
}

export async function del(store: StoreName, key: IDBValidKey): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(store, 'readwrite');
  tx.objectStore(store).delete(key);
  await txDone(tx);
}

export async function delMany(store: StoreName, keys: IDBValidKey[]): Promise<void> {
  if (!keys.length) return;
  const db = await openDB();
  const tx = db.transaction(store, 'readwrite');
  const s = tx.objectStore(store);
  for (const k of keys) s.delete(k);
  await txDone(tx);
}

export async function clear(stores: StoreName[]): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(stores, 'readwrite');
  for (const s of stores) tx.objectStore(s).clear();
  await txDone(tx);
}

/** 1回答の記録をまとめて保存（progress と answers を同一トランザクションで） */
export async function saveAnswer(progress: Progress, log: AnswerLog): Promise<number> {
  const db = await openDB();
  const tx = db.transaction(['progress', 'answers'], 'readwrite');
  tx.objectStore('progress').put(progress);
  const r = tx.objectStore('answers').add(log);
  let id = 0;
  r.onsuccess = () => (id = r.result as number);
  await txDone(tx);
  return id;
}

/** kv ストア（設定・周回情報・同梱データ版数） */
export const kv = {
  get: <T>(key: string) => get<T>('kv', key),
  set: (key: string, value: unknown) => put('kv', value, key),
  async entries(): Promise<Record<string, unknown>> {
    const db = await openDB();
    const s = db.transaction('kv').objectStore('kv');
    const [keys, vals] = await Promise.all([reqP(s.getAllKeys()), reqP(s.getAll())]);
    const out: Record<string, unknown> = {};
    keys.forEach((k, i) => (out[String(k)] = vals[i]));
    return out;
  },
};

export type { Question, Session, Progress, AnswerLog };
