/**
 * 純粋関数のみ（DB・DOMに依存しない）。単体テストの対象。
 */
import {
  CATEGORIES,
  type AnswerLog,
  type Category,
  type CategoryStat,
  type ChoiceId,
  type Progress,
  type Question,
  type Session,
  type SessionResult,
} from '../types';

const DAY = 24 * 60 * 60 * 1000;
/** 間隔反復：間違えた直後 → 翌日 → 3日後 → 7日後 → 14日後 → 30日後 */
export const REVIEW_INTERVAL_DAYS = [1, 3, 7, 14, 30];

export function startOfDay(t: number): number {
  const d = new Date(t);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

export function emptyProgress(questionId: string): Progress {
  return {
    questionId,
    attemptCount: 0,
    correctCount: 0,
    wrongCount: 0,
    consecutiveCorrect: 0,
    consecutiveWrong: 0,
    firstAnswer: null,
    firstCorrect: null,
    firstAnsweredAt: null,
    lastAnswer: null,
    lastCorrect: null,
    lastAnsweredAt: null,
    lastWrongAt: null,
    lastCycle: 0,
    dueAt: null,
  };
}

/** 回答1件を進捗に反映（初回回答・直近回答・連続正誤・復習期限） */
export function applyAnswer(
  prev: Progress | undefined,
  questionId: string,
  selected: ChoiceId,
  correct: boolean,
  now: number,
  cycle: number,
): Progress {
  const p: Progress = { ...(prev ?? emptyProgress(questionId)) };
  if (p.attemptCount === 0) {
    p.firstAnswer = selected;
    p.firstCorrect = correct;
    p.firstAnsweredAt = now;
  }
  p.attemptCount += 1;
  p.lastAnswer = selected;
  p.lastCorrect = correct;
  p.lastAnsweredAt = now;
  p.lastCycle = Math.max(p.lastCycle, cycle);
  if (correct) {
    p.correctCount += 1;
    p.consecutiveCorrect += 1;
    p.consecutiveWrong = 0;
    if (p.wrongCount > 0) {
      const idx = p.consecutiveCorrect - 1;
      p.dueAt = idx < REVIEW_INTERVAL_DAYS.length ? startOfDay(now) + REVIEW_INTERVAL_DAYS[idx] * DAY : null;
    } else {
      p.dueAt = null;
    }
  } else {
    p.wrongCount += 1;
    p.consecutiveWrong += 1;
    p.consecutiveCorrect = 0;
    p.lastWrongAt = now;
    p.dueAt = now; // 間違えた直後から復習対象
  }
  return p;
}

export type Mastery = 'unanswered' | 'weak' | 'review' | 'mastered';
export const MASTERY_LABEL: Record<Mastery, string> = {
  unanswered: '未回答',
  weak: '苦手',
  review: '要復習',
  mastered: '習得',
};

export function mastery(p: Progress | undefined): Mastery {
  if (!p || p.attemptCount === 0) return 'unanswered';
  if (p.lastCorrect && (p.wrongCount === 0 || p.consecutiveCorrect >= 3)) return 'mastered';
  if (!p.lastCorrect && p.wrongCount >= 2) return 'weak';
  return 'review';
}

// ===== 乱数・シャッフル =====

export type Rng = () => number;

export const cryptoRng: Rng = () => {
  const a = new Uint32Array(1);
  crypto.getRandomValues(a);
  return a[0] / 2 ** 32;
};

/** Fisher–Yates（元配列は変更しない） */
export function shuffle<T>(arr: readonly T[], rng: Rng = cryptoRng): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** 選択肢セットの同一性判定用シグネチャ */
export function choiceSignature(q: Question): string {
  return q.choices
    .map((c) => c.text.normalize('NFKC').replace(/\s+/g, ''))
    .join('\u0001');
}

// ===== 出題 =====

export interface SelectContext {
  progress: Map<string, Progress>;
  cycle: number;
  now: number;
  weakCategories?: Set<Category>;
  rng?: Rng;
}

export type SelectOrder = 'priority' | 'keep';

/**
 * 出題する問題を確定する。
 * - 同一IDは絶対に重複させない
 * - 同一選択肢セットは可能な限り避ける（足りない場合のみ許容）
 * - priority：①今周回で未出題かつ未回答 → ②今周回で未出題 → ③今周回で出題済み。
 *   ②③の中では「最近出題されていない」「間違えた」「弱点分野」の順に重み付け。
 */
export function selectQuestions(pool: Question[], n: number, ctx: SelectContext, order: SelectOrder = 'priority'): Question[] {
  const rng = ctx.rng ?? cryptoRng;
  const uniq = new Map<string, Question>();
  for (const q of pool) if (!uniq.has(q.id)) uniq.set(q.id, q);
  let list = [...uniq.values()];

  if (order === 'priority') {
    const shuffled = shuffle(list, rng);
    const scored = shuffled.map((q, i) => {
      const p = ctx.progress.get(q.id);
      const attempted = !!p && p.attemptCount > 0;
      const servedThisCycle = !!p && p.lastCycle >= ctx.cycle;
      const tier = !attempted ? 0 : !servedThisCycle ? 1 : 2;
      let score = 0;
      if (attempted && p) {
        const days = p.lastAnsweredAt ? (ctx.now - p.lastAnsweredAt) / DAY : 0;
        score += Math.min(days, 60) / 10; // 最近出題されていない（最大6）
        if (p.lastCorrect === false) score += 3; // 間違えた
        if (ctx.weakCategories?.has(q.category)) score += 1.5; // 弱点分野
      }
      return { q, tier, score, i };
    });
    scored.sort((a, b) => a.tier - b.tier || b.score - a.score || a.i - b.i);
    list = scored.map((s) => s.q);
  }

  const picked: Question[] = [];
  const sigs = new Set<string>();
  const skipped: Question[] = [];
  for (const q of list) {
    if (picked.length >= n) break;
    const sig = choiceSignature(q);
    if (sigs.has(sig)) {
      skipped.push(q);
      continue;
    }
    sigs.add(sig);
    picked.push(q);
  }
  for (const q of skipped) {
    if (picked.length >= n) break;
    picked.push(q);
  }
  if (order === 'keep') {
    const pos = new Map(list.map((q, i) => [q.id, i]));
    picked.sort((a, b) => pos.get(a.id)! - pos.get(b.id)!);
  }
  return picked;
}

/** 今日の学習：復習期限 → 今日間違えた → 未回答・優先度順 */
export function selectToday(pool: Question[], n: number, ctx: SelectContext): Question[] {
  const today = startOfDay(ctx.now);
  const due: Question[] = [];
  const rest: Question[] = [];
  for (const q of pool) {
    const p = ctx.progress.get(q.id);
    const answeredCorrectToday = p?.lastAnsweredAt != null && p.lastAnsweredAt >= today && p.lastCorrect === true;
    if (answeredCorrectToday) continue;
    if (p?.dueAt != null && p.dueAt <= ctx.now) due.push(q);
    else rest.push(q);
  }
  due.sort((a, b) => ctx.progress.get(a.id)!.dueAt! - ctx.progress.get(b.id)!.dueAt!);
  const first = selectQuestions(due, n, ctx, 'keep');
  const ids = new Set(first.map((q) => q.id));
  const more = selectQuestions(
    rest.filter((q) => !ids.has(q.id)),
    n - first.length,
    ctx,
    'priority',
  );
  return [...first, ...more];
}

/** 今周回の対象がすべて出題済みか（全問1周の判定） */
export function isCycleComplete(pool: Question[], progress: Map<string, Progress>, cycle: number): boolean {
  if (!pool.length) return false;
  return pool.every((q) => (progress.get(q.id)?.lastCycle ?? 0) >= cycle);
}

// ===== 統計 =====

export function rate(correct: number, total: number): number {
  return total === 0 ? 0 : (correct / total) * 100;
}

export function fmtRate(r: number): string {
  return `${Math.round(r)}%`;
}

export interface CategorySummary {
  category: Category;
  questionCount: number;
  answeredCount: number;
  unansweredCount: number;
  wrongQuestionCount: number;
  attempts: number;
  correct: number;
  rate: number;
  /** 回答数が少なく参考値 */
  tentative: boolean;
}

export const TENTATIVE_THRESHOLD = 5;

export function categorySummaries(questions: Question[], progress: Map<string, Progress>): CategorySummary[] {
  return CATEGORIES.map((category) => {
    const qs = questions.filter((q) => q.category === category);
    let attempts = 0;
    let correct = 0;
    let answered = 0;
    let wrongQ = 0;
    for (const q of qs) {
      const p = progress.get(q.id);
      if (!p || p.attemptCount === 0) continue;
      answered++;
      attempts += p.attemptCount;
      correct += p.correctCount;
      if (p.lastCorrect === false) wrongQ++;
    }
    return {
      category,
      questionCount: qs.length,
      answeredCount: answered,
      unansweredCount: qs.length - answered,
      wrongQuestionCount: wrongQ,
      attempts,
      correct,
      rate: rate(correct, attempts),
      tentative: attempts < TENTATIVE_THRESHOLD,
    };
  });
}

/** 弱点ランキング（回答のある分野を正答率の低い順） */
export function weakRanking(summaries: CategorySummary[]): CategorySummary[] {
  return summaries
    .filter((s) => s.attempts > 0)
    .sort((a, b) => a.rate - b.rate || Number(a.tentative) - Number(b.tentative) || b.attempts - a.attempts);
}

export function weakCategorySet(summaries: CategorySummary[], top = 2): Set<Category> {
  return new Set(
    weakRanking(summaries)
      .filter((s) => !s.tentative)
      .slice(0, top)
      .map((s) => s.category),
  );
}

export interface OverallStats {
  totalAnswers: number;
  correct: number;
  wrong: number;
  rate: number;
  today: number;
  todayCorrect: number;
  week: number;
  streak: number;
  studiedToday: boolean;
}

export function overallStats(logs: AnswerLog[], now: number): OverallStats {
  const today = startOfDay(now);
  const weekStart = today - 6 * DAY;
  let correct = 0;
  let todayN = 0;
  let todayC = 0;
  let week = 0;
  const days = new Set<number>();
  for (const l of logs) {
    if (l.correct) correct++;
    const d = startOfDay(l.answeredAt);
    days.add(d);
    if (d === today) {
      todayN++;
      if (l.correct) todayC++;
    }
    if (d >= weekStart) week++;
  }
  // 連続学習日数：今日（未学習なら昨日）から遡る
  let streak = 0;
  let cursor = days.has(today) ? today : today - DAY;
  while (days.has(cursor)) {
    streak++;
    cursor = startOfDay(cursor - DAY / 2);
  }
  return {
    totalAnswers: logs.length,
    correct,
    wrong: logs.length - correct,
    rate: rate(correct, logs.length),
    today: todayN,
    todayCorrect: todayC,
    week,
    streak,
    studiedToday: days.has(today),
  };
}

/** セッションの採点 */
export function scoreSession(session: Session, qmap: Map<string, Question>, now: number): SessionResult {
  const byCat = new Map<Category, { total: number; correct: number }>();
  let correct = 0;
  let answered = 0;
  let total = 0;
  for (const id of session.questionIds) {
    const q = qmap.get(id);
    if (!q) continue; // 削除済み問題はスキップ（クラッシュさせない）
    total++;
    const a = session.answers[id];
    const c = byCat.get(q.category) ?? { total: 0, correct: 0 };
    c.total++;
    if (a != null) {
      answered++;
      if (a === q.correctAnswer) {
        correct++;
        c.correct++;
      }
    }
    byCat.set(q.category, c);
  }
  const byCategory: CategoryStat[] = CATEGORIES.filter((c) => byCat.has(c)).map((category) => {
    const v = byCat.get(category)!;
    return { category, total: v.total, correct: v.correct, rate: rate(v.correct, v.total) };
  });
  return {
    total,
    answered,
    correct,
    wrong: answered - correct,
    unanswered: total - answered,
    rate: rate(correct, total),
    passed: session.passingScore == null ? null : correct >= session.passingScore,
    byCategory,
    finishedAt: now,
  };
}

// ===== 検索 =====

export function normalizeForSearch(s: string): string {
  return s.normalize('NFKC').toLowerCase().replace(/\s+/g, '');
}

export function searchText(q: Question): string {
  const e = q.explanation;
  return normalizeForSearch(
    [
      q.questionText,
      ...(q.items ?? []).map((i) => i.text),
      ...q.choices.map((c) => c.text),
      ...(q.annotations ?? []).map((a) => a.text),
      ...(q.tables ?? []).flatMap((t) => [t.title ?? '', t.caption ?? '', ...t.rows.flat()]),
      ...(e?.notes ?? []),
      e?.summary ?? '',
      ...(e?.choices ?? []).flatMap((c) => [c.reason, c.correctContent ?? '', c.wrongQuote ?? '']),
      ...(e?.items ?? []).flatMap((c) => [c.reason, c.correctContent ?? '']),
      ...(e?.trapPoints ?? []),
      ...(e?.memoryPoints ?? []),
      ...(q.legalBasis ?? []),
      q.category,
      q.subcategory ?? '',
      q.examName,
    ].join('\n'),
  );
}

/** 全角/半角・空白を無視し、スペース区切りはAND検索 */
export function searchQuestions(questions: Question[], index: Map<string, string>, query: string): Question[] {
  const terms = query
    .split(/[\s　]+/)
    .map(normalizeForSearch)
    .filter(Boolean);
  if (!terms.length) return [];
  return questions.filter((q) => {
    const t = index.get(q.id) ?? searchText(q);
    return terms.every((term) => t.includes(term));
  });
}

export function choiceMark(id: number): string {
  return ['①', '②', '③', '④'][id - 1] ?? String(id);
}
