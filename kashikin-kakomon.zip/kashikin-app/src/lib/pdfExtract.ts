/**
 * PDFからのテキスト抽出（端末内で完結。外部送信なし）。
 * pdf.js は取込画面を開いたときだけ遅延読み込みする。
 */
import type { PageLines } from './pdfParse';

type PdfJs = typeof import('pdfjs-dist');
type PDFDocumentProxy = import('pdfjs-dist').PDFDocumentProxy;

let pdfjsPromise: Promise<PdfJs> | null = null;

function base(path: string): string {
  return new URL(path, document.baseURI).href;
}

export function loadPdfJs(): Promise<PdfJs> {
  if (!pdfjsPromise) {
    // legacy ビルド：Safari 未実装の新しいAPI（Map.prototype.getOrInsertComputed 等）を補う polyfill 入り
    pdfjsPromise = (import('pdfjs-dist/legacy/build/pdf.mjs') as Promise<PdfJs>).then((m) => {
      m.GlobalWorkerOptions.workerSrc = base('pdfjs/pdf.worker.min.mjs');
      return m;
    });
  }
  return pdfjsPromise;
}

export async function openPdf(data: ArrayBuffer): Promise<PDFDocumentProxy> {
  const pdfjs = await loadPdfJs();
  return pdfjs.getDocument({
    data: new Uint8Array(data),
    cMapUrl: base('pdfjs/cmaps/'),
    cMapPacked: true,
    standardFontDataUrl: base('pdfjs/standard_fonts/'),
  }).promise;
}

interface TItem {
  str: string;
  x: number;
  y: number;
  w: number;
  h: number;
}

/** ページのテキスト項目を座標で行にまとめる */
export async function extractLines(doc: PDFDocumentProxy): Promise<PageLines[]> {
  const out: PageLines[] = [];
  for (let i = 1; i <= doc.numPages; i++) {
    const page = await doc.getPage(i);
    const content = await page.getTextContent();
    const items: TItem[] = [];
    for (const it of content.items as Array<{ str?: string; transform?: number[]; width?: number; height?: number }>) {
      if (typeof it.str !== 'string' || !it.transform) continue;
      if (!it.str) continue;
      const [, , , d, e, f] = it.transform;
      items.push({ str: it.str, x: e, y: f, w: it.width ?? 0, h: Math.abs(it.height || d || 10) });
    }
    items.sort((a, b) => b.y - a.y || a.x - b.x);
    const lines: TItem[][] = [];
    for (const it of items) {
      const last = lines[lines.length - 1];
      const tol = Math.max(2, it.h * 0.45);
      if (last && Math.abs(last[0].y - it.y) <= tol) last.push(it);
      else lines.push([it]);
    }
    const texts = lines.map((ln) => {
      ln.sort((a, b) => a.x - b.x);
      let s = '';
      let prevEnd: number | null = null;
      for (const it of ln) {
        if (prevEnd != null && it.x - prevEnd > it.h * 0.6) s += ' ';
        s += it.str;
        prevEnd = it.x + it.w;
      }
      return s;
    });
    out.push({ page: i, lines: texts });
    page.cleanup();
  }
  return out;
}

/** 確認画面で原本ページを表示する */
export async function renderPage(doc: PDFDocumentProxy, pageNo: number, canvas: HTMLCanvasElement, cssWidth: number): Promise<void> {
  const page = await doc.getPage(pageNo);
  const vp1 = page.getViewport({ scale: 1 });
  const dpr = Math.min(window.devicePixelRatio || 1, 3);
  const scale = (cssWidth / vp1.width) * dpr;
  const vp = page.getViewport({ scale });
  canvas.width = Math.floor(vp.width);
  canvas.height = Math.floor(vp.height);
  canvas.style.width = `${cssWidth}px`;
  canvas.style.height = `${Math.floor(vp.height / dpr)}px`;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  await page.render({ canvas, canvasContext: ctx, viewport: vp }).promise;
}

export type { PDFDocumentProxy };
