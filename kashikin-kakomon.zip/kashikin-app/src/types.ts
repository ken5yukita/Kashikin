// ===== 問題データ =====

export const CATEGORIES = [
  '貸金業法',
  '利息制限法',
  '出資法',
  '民法',
  '商法',
  '民事手続',
  '個人情報保護',
  '犯罪収益移転防止法',
  '財務・会計',
  '資金需要者保護',
  'その他関連法令',
] as const;
export type Category = (typeof CATEGORIES)[number];

export type ChoiceId = 1 | 2 | 3 | 4;

export interface Choice {
  id: ChoiceId;
  text: string;
}

/** 問題文中の小問（ａ〜ｄ、ア〜エ など）。組合せ問題・個数問題で使用 */
export interface SubItem {
  label: string;
  text: string;
}

/** 注釈。anchorText が null の場合は位置不明（本文へは挿入しない） */
/** 問題に含まれる表（財務諸表など） */
export interface QTable {
  title?: string;
  caption?: string;
  header?: string[];
  rows: string[][];
}

export interface Annotation {
  text: string;
  anchorText: string | null;
}

/** 記述そのものの内容の正誤（「適切／不適切」）。正答肢かどうかとは別 */
export type StatementVerdict = 'appropriate' | 'inappropriate';

export interface ChoiceExplanation {
  id: ChoiceId;
  verdict: StatementVerdict;
  /** 誤っている箇所の引用。必ず選択肢（または小問）本文に含まれる文字列 */
  wrongQuote?: string;
  /** 正しい内容 */
  correctContent?: string;
  /** 理由 */
  reason: string;
}

export interface Explanation {
  summary?: string;
  /** 'option'＝組み合わせ・個数問題の選択肢（判定を「正しい／誤り」で表示） */
  choiceKind?: 'statement' | 'option';
  choices: ChoiceExplanation[];
  /** 組合せ問題用：小問ごとの解説（label は SubItem.label と一致） */
  items?: Array<{ label: string; verdict: StatementVerdict; wrongQuote?: string; correctContent?: string; reason: string }>;
  trapPoints?: string[];
  memoryPoints?: string[];
  /** 法改正等の注意（試験実施時点と現行法で結論が変わる場合など） */
  notes?: string[];
}

export type SourceType = 'official' | 'original' | 'user';

export interface Question {
  id: string;
  examId: string;
  examName: string;
  questionNumber: number;
  category: Category;
  subcategory?: string;
  /** 試験問題用紙の科目区分（公式） */
  section?: string;
  questionText: string;
  items?: SubItem[];
  tables?: QTable[];
  choices: Choice[];
  correctAnswer: ChoiceId;
  annotations?: Annotation[];
  explanation?: Explanation;
  legalBasis?: string[];
  relatedQuestionIds?: string[];
  sourceType: SourceType;
  source: string;
  verified: boolean;
  /** 取込時に検出した要確認事項（文字化け等） */
  issues?: string[];
  importedAt?: number;
  updatedAt?: number;
}

// ===== 試験回 =====

export interface ExamInfo {
  examId: string;
  examName: string;
  round: number | null;
  examDate: string;
  questionCount: number;
  /** 合格基準点（問）。不明な場合は null（推測しない） */
  passingScore: number | null;
  passingScoreSource: string;
  source: string;
  /** 公式PDFのファイル名（取込時の自動判定用） */
  paperFile?: string;
  answerFile?: string;
}

// ===== 学習データ =====

export interface Progress {
  questionId: string;
  attemptCount: number;
  correctCount: number;
  wrongCount: number;
  consecutiveCorrect: number;
  consecutiveWrong: number;
  firstAnswer: ChoiceId | null;
  firstCorrect: boolean | null;
  firstAnsweredAt: number | null;
  lastAnswer: ChoiceId | null;
  lastCorrect: boolean | null;
  lastAnsweredAt: number | null;
  lastWrongAt: number | null;
  /** 全問1周の何周目に最後に回答したか */
  lastCycle: number;
  /** 次回復習期限（間隔反復）。null は期限なし */
  dueAt: number | null;
}

export interface AnswerLog {
  id?: number;
  questionId: string;
  selected: ChoiceId;
  correct: boolean;
  answeredAt: number;
  sessionId: string;
  mode: SessionMode;
  category: Category;
}

export type SessionMode =
  | 'random'
  | 'mock'
  | 'exam-study'
  | 'exam-mock'
  | 'category'
  | 'unanswered'
  | 'wrong'
  | 'bookmark'
  | 'weak'
  | 'today'
  | 'search'
  | 'single'
  | 'retry';

export interface Session {
  id: string;
  mode: SessionMode;
  title: string;
  /** 開始時点で確定した出題順（途中で入れ替えない） */
  questionIds: string[];
  answers: Record<string, ChoiceId>;
  /** 学習モードで回答確定済みの問題（再回答不可） */
  locked: Record<string, true>;
  currentIndex: number;
  startTime: number;
  endTime: number | null;
  /** 制限時間（ミリ秒）。模試のみ */
  timeLimitMs: number | null;
  /** 模試＝回答中は解説非表示、回答変更可 */
  isExam: boolean;
  examId: string | null;
  passingScore: number | null;
  passingScoreLabel: string | null;
  finished: boolean;
  result?: SessionResult;
}

export interface SessionResult {
  total: number;
  answered: number;
  correct: number;
  wrong: number;
  unanswered: number;
  rate: number;
  passed: boolean | null;
  byCategory: CategoryStat[];
  finishedAt: number;
}

export interface CategoryStat {
  category: Category;
  total: number;
  correct: number;
  rate: number;
}

export type ThemeSetting = 'system' | 'light' | 'dark';
export type FontSize = 'small' | 'medium' | 'large';

export interface Settings {
  theme: ThemeSetting;
  fontSize: FontSize;
  includeUnverifiedInMock: boolean;
  includeUnverifiedInStudy: boolean;
  dailyGoal: number;
  showCategoryOnQuestion: boolean;
}

export const DEFAULT_SETTINGS: Settings = {
  theme: 'system',
  fontSize: 'medium',
  includeUnverifiedInMock: false,
  includeUnverifiedInStudy: true,
  dailyGoal: 20,
  showCategoryOnQuestion: true,
};

export interface Meta {
  /** 現在の周回（1始まり） */
  currentCycle: number;
  /** 各周回の完了日時 */
  cycleCompletedAt: number[];
}

export const DEFAULT_META: Meta = { currentCycle: 1, cycleCompletedAt: [] };
