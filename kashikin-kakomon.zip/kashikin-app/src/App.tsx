import { useEffect } from 'react';
import type { Category } from './types';
import { useStore } from './lib/store';
import { openSingle } from './lib/start';
import { useRoute } from './router';
import { Home } from './screens/Home';
import { SessionScreen } from './screens/SessionScreen';
import { ResultScreen } from './screens/ResultScreen';
import {
  BookmarksScreen,
  CategoriesScreen,
  CategoryDetail,
  ExamDetail,
  ExamsScreen,
  PendingScreen,
  SearchScreen,
  StatsScreen,
  WrongScreen,
} from './screens/Lists';
import { DataInfoScreen, SettingsScreen } from './screens/SettingsScreen';
import { ImportScreen } from './screens/ImportScreen';

function OpenSingle({ qid }: { qid: string }) {
  useEffect(() => {
    void openSingle(qid);
  }, [qid]);
  return <div className="page center-msg">読み込み中…</div>;
}

export function App() {
  const st = useStore();
  const { parts, query } = useRoute();

  if (!st.ready) return <div className="page center-msg" aria-busy="true">読み込み中…</div>;
  if (st.fatal)
    return (
      <div className="page center-msg">
        <div>
          <p>{st.fatal}</p>
          <p className="small">プライベートブラウズでは保存領域が使えない場合があります。</p>
        </div>
      </div>
    );

  const [a, b] = parts;
  const dec = (s: string) => decodeURIComponent(s ?? '');
  let screen;
  switch (a) {
    case undefined:
      screen = <Home />;
      break;
    case 's': {
      const i = query.get('i');
      screen = <SessionScreen key={b} id={b} startAt={i != null ? Number(i) : null} />;
      break;
    }
    case 'r':
      screen = <ResultScreen id={b} />;
      break;
    case 'open':
      screen = <OpenSingle qid={dec(b)} />;
      break;
    case 'exams':
      screen = <ExamsScreen />;
      break;
    case 'exam':
      screen = <ExamDetail examId={b} />;
      break;
    case 'categories':
      screen = <CategoriesScreen />;
      break;
    case 'category':
      screen = <CategoryDetail category={dec(b) as Category} />;
      break;
    case 'wrong':
      screen = <WrongScreen />;
      break;
    case 'bookmarks':
      screen = <BookmarksScreen />;
      break;
    case 'pending':
      screen = <PendingScreen />;
      break;
    case 'search':
      screen = <SearchScreen />;
      break;
    case 'stats':
      screen = <StatsScreen />;
      break;
    case 'settings':
      screen = <SettingsScreen />;
      break;
    case 'data':
      screen = <DataInfoScreen />;
      break;
    case 'import':
      screen = <ImportScreen />;
      break;
    default:
      screen = <Home />;
  }
  return (
    <>
      {screen}
      {st.toast && (
        <div className="toast" role="status" aria-live="polite">
          {st.toast}
        </div>
      )}
    </>
  );
}
