import type { ReactNode } from 'react';
import { back, navigate } from '../router';

type IconName =
  | 'home' | 'bookmark' | 'bookmark-fill' | 'chev' | 'back' | 'search' | 'chart' | 'gear' | 'list'
  | 'shuffle' | 'clock' | 'book' | 'layers' | 'alert' | 'star' | 'download' | 'upload' | 'check' | 'grid' | 'today' | 'new';

const PATHS: Record<IconName, ReactNode> = {
  home: <path d="M3.5 11 12 4l8.5 7M6 9.5V20h4.5v-5.5h3V20H18V9.5" />,
  bookmark: <path d="M6.5 3.5h11v17L12 16l-5.5 4.5z" />,
  'bookmark-fill': <path d="M6.5 3.5h11v17L12 16l-5.5 4.5z" fill="currentColor" />,
  chev: <path d="m9 5 7 7-7 7" />,
  back: <path d="m15 5-7 7 7 7" />,
  search: <><circle cx="10.5" cy="10.5" r="6" /><path d="m15 15 5 5" /></>,
  chart: <path d="M4 20h16M7 16v-5M12 16V6M17 16v-8" />,
  gear: <><circle cx="12" cy="12" r="3" /><path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M5.5 18.5l1.7-1.7M16.8 7.2l1.7-1.7" /></>,
  list: <path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01" />,
  shuffle: <path d="M3 7h4c4 0 6 10 10 10h4M3 17h4c1.6 0 2.8-1.6 3.8-3.6M14 8.6C15 7.4 16 7 17 7h4M18 4l3 3-3 3M18 14l3 3-3 3" />,
  clock: <><circle cx="12" cy="12" r="8.5" /><path d="M12 7.5V12l3 2" /></>,
  book: <path d="M4 5.5C6.5 4.5 9.5 4.5 12 6c2.5-1.5 5.5-1.5 8-.5v13c-2.5-1-5.5-1-8 .5-2.5-1.5-5.5-1.5-8-.5zM12 6v13" />,
  layers: <path d="m12 4 8.5 4.5L12 13 3.5 8.5zM3.5 12.5 12 17l8.5-4.5M3.5 16.5 12 21l8.5-4.5" />,
  alert: <><path d="M12 4 2.5 20h19z" /><path d="M12 10v4.5M12 17.5h.01" /></>,
  star: <path d="m12 3.5 2.6 5.5 6 .7-4.4 4.1 1.1 6-5.3-3-5.3 3 1.1-6L3.4 9.7l6-.7z" />,
  download: <path d="M12 4v11m0 0-4.5-4.5M12 15l4.5-4.5M4.5 19.5h15" />,
  upload: <path d="M12 16V5m0 0L7.5 9.5M12 5l4.5 4.5M4.5 19.5h15" />,
  check: <path d="m5 12.5 4.5 4.5L19 7.5" />,
  grid: <path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z" />,
  today: <><rect x="3.5" y="5" width="17" height="15" rx="2" /><path d="M3.5 9.5h17M8 3v4M16 3v4M9 14.5l2 2 4-4" /></>,
  new: <><circle cx="12" cy="12" r="8.5" /><path d="M12 8v8M8 12h8" /></>,
};

export function Icon({ name, className }: { name: IconName; className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
      {PATHS[name]}
    </svg>
  );
}

export function TopBar({
  title,
  sub,
  subUrgent,
  left,
  right,
}: {
  title: ReactNode;
  sub?: ReactNode;
  subUrgent?: boolean;
  left?: ReactNode;
  right?: ReactNode;
}) {
  return (
    <header className="topbar">
      <div className="topbar-inner">
        <div className="left">{left ?? <BackButton />}</div>
        <div className="topbar-title" aria-live="polite">
          {title}
          {sub != null && <span className={`topbar-sub num${subUrgent ? ' urgent' : ''}`}>{sub}</span>}
        </div>
        <div className="right">{right}</div>
      </div>
    </header>
  );
}

export function BackButton({ to }: { to?: string }) {
  return (
    <button className="icon-btn" onClick={() => (to ? navigate(to) : back())} aria-label="戻る">
      <Icon name="back" />
      <span>戻る</span>
    </button>
  );
}

export function HomeButton({ onClick }: { onClick?: () => void }) {
  return (
    <button className="icon-btn" onClick={onClick ?? (() => navigate('/'))} aria-label="ホームへ戻る">
      <Icon name="home" />
      <span>ホーム</span>
    </button>
  );
}

export function Row({
  title,
  desc,
  value,
  icon,
  onClick,
  href,
  disabled,
  chevron = true,
  label,
}: {
  title: ReactNode;
  desc?: ReactNode;
  value?: ReactNode;
  icon?: IconName;
  onClick?: () => void;
  href?: string;
  disabled?: boolean;
  chevron?: boolean;
  label?: string;
}) {
  const inner = (
    <>
      {icon && (
        <span className="lead-icon">
          <Icon name={icon} />
        </span>
      )}
      <span className="grow">
        <span className="title">{title}</span>
        {desc && <span className="desc">{desc}</span>}
      </span>
      {value != null && <span className="val">{value}</span>}
      {chevron && (onClick || href) && <Icon name="chev" className="chev" />}
    </>
  );
  if (href)
    return (
      <a className="row" href={'#' + href} aria-label={label}>
        {inner}
      </a>
    );
  if (onClick)
    return (
      <button className="row" onClick={onClick} disabled={disabled} aria-label={label}>
        {inner}
      </button>
    );
  return <div className="row">{inner}</div>;
}

export function Group({ title, children }: { title?: string; children: ReactNode }) {
  return (
    <section>
      {title && <h2 className="group-title">{title}</h2>}
      <div className="group">{children}</div>
    </section>
  );
}

/** 採点マーク（色に依存せず形で区別：○と×） */
export function MarkSvg({ ok, size = 92 }: { ok: boolean; size?: number }) {
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} aria-hidden="true">
      {ok ? (
        <circle className="mark-path" cx="50" cy="50" r="36" fill="none" stroke="currentColor" strokeWidth="10" strokeLinecap="round" />
      ) : (
        <>
          <path className="mark-path" d="M22 22 78 78" stroke="currentColor" strokeWidth="11" strokeLinecap="round" />
          <path className="mark-path second" d="M78 22 22 78" stroke="currentColor" strokeWidth="11" strokeLinecap="round" />
        </>
      )}
    </svg>
  );
}

export function SmallMark({ ok }: { ok: boolean | null }) {
  if (ok == null) return <span className="mark-ng" aria-label="未回答" style={{ color: 'var(--ink-3)', textAlign: 'center' }}>－</span>;
  return (
    <svg className={ok ? 'mark-ok' : 'mark-ng'} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.6} strokeLinecap="round" role="img" aria-label={ok ? '正解' : '不正解'}>
      {ok ? <circle cx="12" cy="12" r="7.5" /> : <path d="M6 6l12 12M18 6 6 18" />}
    </svg>
  );
}

export function Empty({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="empty-state">
      <p>{children}</p>
      {action}
    </div>
  );
}

export function formatDuration(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return h > 0 ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}` : `${m}:${String(sec).padStart(2, '0')}`;
}

export function formatDate(t: number | null | undefined): string {
  if (!t) return '－';
  const d = new Date(t);
  return `${d.getFullYear()}/${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}
