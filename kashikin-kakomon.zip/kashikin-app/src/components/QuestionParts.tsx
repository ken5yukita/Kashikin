import { Fragment, type ReactNode } from 'react';
import type { ChoiceId, Question } from '../types';
import { choiceMark } from '../lib/logic';
import { quoteMatches } from '../lib/validate';
import { getExam } from '../data/exams';
import { MarkSvg } from './ui';

/** 問題文の指示部分（適切なもの／適切でないもの 等）だけを強調。文言は一切変えない */
const EMPHASIS = /(適切でないもの|適切なもの|不適切なもの|誤っているもの|正しいもの|誤っているものの|組み合わせ|個数)/g;
export function emphasize(text: string): ReactNode {
  const parts = text.split(EMPHASIS);
  return parts.map((p, i) => (i % 2 === 1 ? <strong key={i}>{p}</strong> : <Fragment key={i}>{p}</Fragment>));
}

export function questionLabel(q: Question): string {
  if (q.sourceType === 'original') return `オリジナル例題 ${q.questionNumber}`;
  const e = getExam(q.examId);
  return e?.round ? `第${e.round}回 問${q.questionNumber}` : `${q.examName} 問${q.questionNumber}`;
}

export function QuestionMeta({ q, showCategory = true }: { q: Question; showCategory?: boolean }) {
  return (
    <div className="q-meta">
      <span className={`tag${q.sourceType === 'original' ? ' orig' : ''}`}>{questionLabel(q)}</span>
      {showCategory && <span className="tag">{q.category}{q.subcategory ? `／${q.subcategory}` : ''}</span>}
      {q.sourceType === 'original' && <span className="tag orig">公式問題ではありません</span>}
      {!q.verified && <span className="tag warn">未検証</span>}
    </div>
  );
}

export function QuestionBody({ q }: { q: Question }) {
  return (
    <>
      <p className="q-text jp">{emphasize(q.questionText)}</p>
      {!!q.items?.length && (
        <ul className="q-items">
          {q.items.map((it) => (
            <li key={it.label} className="q-item jp">
              <span className="lbl">{it.label}</span>
              <span>{it.text}</span>
            </li>
          ))}
        </ul>
      )}
      {!!q.tables?.length &&
        q.tables.map((t, i) => (
          <figure key={i} className="q-table">
            {t.title && <figcaption>{t.title}</figcaption>}
            {t.caption && <p className="q-table-cap">{t.caption}</p>}
            <div className="q-table-scroll">
              <table>
                {t.header && (
                  <thead>
                    <tr>{t.header.map((h, j) => <th key={j} scope="col">{h}</th>)}</tr>
                  </thead>
                )}
                <tbody>
                  {t.rows.map((r, j) => (
                    <tr key={j}>{r.map((c, k) => (k === 0 ? <th key={k} scope="row">{c}</th> : <td key={k}>{c}</td>))}</tr>
                  ))}
                </tbody>
              </table>
            </div>
          </figure>
        ))}
      {!!q.annotations?.length &&
        q.annotations.map((a, i) => (
          <div key={i} className="annot jp" role="note">
            <b>注釈</b>
            {a.anchorText ? `（「${a.anchorText}」について）` : ''}　{a.text}
          </div>
        ))}
    </>
  );
}

export function ChoiceList({
  q,
  selected,
  reveal,
  disabled,
  onSelect,
}: {
  q: Question;
  selected: ChoiceId | undefined;
  reveal: boolean;
  disabled: boolean;
  onSelect: (c: ChoiceId) => void;
}) {
  return (
    <ul className="choices" role="radiogroup" aria-label="選択肢">
      {q.choices.map((c) => {
        const isSel = selected === c.id;
        const isAns = q.correctAnswer === c.id;
        const cls = ['choice', 'jp'];
        if (isSel) cls.push('selected');
        if (reveal && isAns) cls.push('is-correct');
        if (reveal && isSel && !isAns) cls.push('is-wrong');
        if (reveal && !isSel && !isAns) cls.push('dim');
        const state = reveal ? `${isAns ? '、正解' : ''}${isSel ? '、あなたの回答' : ''}` : isSel ? '、選択中' : '';
        return (
          <li key={c.id}>
            <button
              className={cls.join(' ')}
              role="radio"
              aria-checked={isSel}
              aria-disabled={disabled}
              aria-label={`${choiceMark(c.id)} ${c.text}${state}`}
              onClick={() => !disabled && onSelect(c.id)}
            >
              <span className="bubble" aria-hidden="true">{c.id}</span>
              <span>
                {c.text}
                {reveal && (isAns || isSel) && (
                  <span className="choice-tags" aria-hidden="true">
                    {isAns && <span className="pill ok">正解</span>}
                    {isSel && <span className={`pill ${isAns ? 'mine' : 'ng'}`}>あなたの回答</span>}
                  </span>
                )}
              </span>
            </button>
          </li>
        );
      })}
    </ul>
  );
}

export function Verdict({ q, selected }: { q: Question; selected: ChoiceId }) {
  const ok = selected === q.correctAnswer;
  return (
    <div className={`verdict ${ok ? 'ok' : 'ng'}`} role="status" aria-live="assertive">
      <MarkSvg ok={ok} />
      <div>
        <div className="verdict-word">{ok ? '正解' : '不正解'}</div>
        <div className="verdict-detail">
          正答は <b>{choiceMark(q.correctAnswer)}</b>
          {!ok && <>　あなたの回答は {choiceMark(selected)}</>}
        </div>
      </div>
    </div>
  );
}

export function ExplanationView({ q, related }: { q: Question; related?: Question[] }) {
  const e = q.explanation;
  return (
    <section className="expl" aria-label="解説">
      {!e && (
        <p className="notice">
          この問題の解説はまだ登録されていません。正答（{choiceMark(q.correctAnswer)}）のみ表示しています。解説データは「データの取込」から追加できます。
        </p>
      )}
      {e?.summary && (
        <>
          <h3>解説</h3>
          <p className="expl-summary jp">{e.summary}</p>
        </>
      )}
      {!!e?.items?.length && (
        <>
          <h3>小問ごとの解説</h3>
          {e.items.map((it) => (
            <ExplainCard key={it.label} q={q} head={it.label} verdict={it.verdict} wrongQuote={it.wrongQuote} correctContent={it.correctContent} reason={it.reason} />
          ))}
        </>
      )}
      {!!e?.choices?.length && (
        <>
          <h3>選択肢ごとの解説</h3>
          {[...e.choices].sort((a, b) => a.id - b.id).map((c) => (
            <ExplainCard
              key={c.id}
              q={q}
              head={choiceMark(c.id)}
              isAnswer={c.id === q.correctAnswer}
              option={e.choiceKind === 'option'}
              verdict={c.verdict}
              wrongQuote={c.wrongQuote}
              correctContent={c.correctContent}
              reason={c.reason}
            />
          ))}
        </>
      )}
      {!!e?.notes?.length && (
        <>
          <h3>法改正等の注意</h3>
          {e.notes.map((t, i) => (
            <p key={i} className="notice jp">{t}</p>
          ))}
        </>
      )}
      {!!e?.trapPoints?.length && (
        <>
          <h3>ひっかけポイント</h3>
          <ul className="points trap">
            {e.trapPoints.map((t, i) => (
              <li key={i} className="jp">{t}</li>
            ))}
          </ul>
        </>
      )}
      {!!e?.memoryPoints?.length && (
        <>
          <h3>ここだけ覚える</h3>
          <ul className="points memo">
            {e.memoryPoints.map((t, i) => (
              <li key={i} className="jp">{t}</li>
            ))}
          </ul>
        </>
      )}
      {!!q.legalBasis?.length && (
        <>
          <h3>法律上の根拠</h3>
          <ul className="basis">
            {q.legalBasis.map((b, i) => (
              <li key={i} className="jp">{b}</li>
            ))}
          </ul>
        </>
      )}
      {!!related?.length && (
        <>
          <h3>関連問題</h3>
          <div className="group">
            {related.map((r) => (
              <a key={r.id} className="row" href={`#/open/${encodeURIComponent(r.id)}`}>
                <span className="grow">
                  <span className="title">{questionLabel(r)}</span>
                  <span className="desc">{r.questionText.slice(0, 48)}…</span>
                </span>
              </a>
            ))}
          </div>
        </>
      )}
      <p className="muted small" style={{ marginTop: 18 }}>出典：{q.source}</p>
    </section>
  );
}

function ExplainCard({
  q,
  head,
  isAnswer,
  option,
  verdict,
  wrongQuote,
  correctContent,
  reason,
}: {
  q: Question;
  head: string;
  isAnswer?: boolean;
  option?: boolean;
  verdict: 'appropriate' | 'inappropriate';
  wrongQuote?: string;
  correctContent?: string;
  reason: string;
}) {
  const quoteOk = wrongQuote ? quoteMatches(q, wrongQuote) : true;
  return (
    <article className={`ce${isAnswer ? ' answer' : ''}`}>
      <div className="ce-head">
        <span className="mk">{head}</span>
        <span className={`ce-verdict ${verdict === 'appropriate' ? 'app' : 'inapp'}`}>
          {option ? (verdict === 'appropriate' ? '正しい' : '誤り') : verdict === 'appropriate' ? '適切（正しい記述）' : '不適切（誤った記述）'}
        </span>
        {isAnswer && <span className="pill ok">正答肢</span>}
      </div>
      <dl>
        {wrongQuote && (
          <>
            <dt>誤っている箇所</dt>
            <dd className="quote jp">「{wrongQuote}」</dd>
            {!quoteOk && <dd className="notice">この引用は問題文と一致しません（データの確認が必要です）</dd>}
          </>
        )}
        {correctContent && (
          <>
            <dt>正しい内容</dt>
            <dd className="fix jp">{correctContent}</dd>
          </>
        )}
        <dt>理由</dt>
        <dd className="jp">{reason}</dd>
      </dl>
    </article>
  );
}
