import { useSyncExternalStore } from 'react';

/** ハッシュルーター（GitHub Pages 等どこに置いても動作し、サーバー設定不要） */
function current(): string {
  const h = location.hash.replace(/^#/, '');
  return h || '/';
}

function subscribe(cb: () => void) {
  window.addEventListener('hashchange', cb);
  return () => window.removeEventListener('hashchange', cb);
}

export function useRoute(): { path: string; parts: string[]; query: URLSearchParams } {
  const full = useSyncExternalStore(subscribe, current);
  const [path, qs] = full.split('?');
  return { path, parts: path.split('/').filter(Boolean), query: new URLSearchParams(qs ?? '') };
}

export function navigate(to: string, opts: { replace?: boolean } = {}) {
  const url = '#' + to;
  if (opts.replace) location.replace(url);
  else location.hash = to;
  window.scrollTo(0, 0);
}

export function back(fallback = '/') {
  if (history.length > 1) history.back();
  else navigate(fallback, { replace: true });
}
