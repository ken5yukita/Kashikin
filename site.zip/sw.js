/* Service Worker：アプリ一式を事前キャッシュし、オフラインで動作させる。
   問題データ(data/*.json)はネット優先・失敗時キャッシュ（更新を受け取るため）。
   学習データは IndexedDB にあり、ここでは扱わない。外部への送信は行わない。 */
const CACHE = 'kashikin-9f5852fa3757';
const PRECACHE = ["./","assets/app-ACI4RVZW.js","assets/app-O244DZCE.css","assets/chunk-HIQGWE75.js","assets/chunk-VPBNXRJZ.js","data/index.json","data/questions/original.json","icons/apple-touch-icon.png","icons/icon-192.png","icons/icon-512-maskable.png","icons/icon-512.png","index.html","manifest.webmanifest","pdfjs/cmaps/78-EUC-H.bcmap","pdfjs/cmaps/78-EUC-V.bcmap","pdfjs/cmaps/78-H.bcmap","pdfjs/cmaps/78-RKSJ-H.bcmap","pdfjs/cmaps/78-RKSJ-V.bcmap","pdfjs/cmaps/78-V.bcmap","pdfjs/cmaps/78ms-RKSJ-H.bcmap","pdfjs/cmaps/78ms-RKSJ-V.bcmap","pdfjs/cmaps/83pv-RKSJ-H.bcmap","pdfjs/cmaps/90ms-RKSJ-H.bcmap","pdfjs/cmaps/90ms-RKSJ-V.bcmap","pdfjs/cmaps/90msp-RKSJ-H.bcmap","pdfjs/cmaps/90msp-RKSJ-V.bcmap","pdfjs/cmaps/90pv-RKSJ-H.bcmap","pdfjs/cmaps/90pv-RKSJ-V.bcmap","pdfjs/cmaps/Add-H.bcmap","pdfjs/cmaps/Add-RKSJ-H.bcmap","pdfjs/cmaps/Add-RKSJ-V.bcmap","pdfjs/cmaps/Add-V.bcmap","pdfjs/cmaps/Adobe-CNS1-0.bcmap","pdfjs/cmaps/Adobe-CNS1-1.bcmap","pdfjs/cmaps/Adobe-CNS1-2.bcmap","pdfjs/cmaps/Adobe-CNS1-3.bcmap","pdfjs/cmaps/Adobe-CNS1-4.bcmap","pdfjs/cmaps/Adobe-CNS1-5.bcmap","pdfjs/cmaps/Adobe-CNS1-6.bcmap","pdfjs/cmaps/Adobe-CNS1-UCS2.bcmap","pdfjs/cmaps/Adobe-GB1-0.bcmap","pdfjs/cmaps/Adobe-GB1-1.bcmap","pdfjs/cmaps/Adobe-GB1-2.bcmap","pdfjs/cmaps/Adobe-GB1-3.bcmap","pdfjs/cmaps/Adobe-GB1-4.bcmap","pdfjs/cmaps/Adobe-GB1-5.bcmap","pdfjs/cmaps/Adobe-GB1-UCS2.bcmap","pdfjs/cmaps/Adobe-Japan1-0.bcmap","pdfjs/cmaps/Adobe-Japan1-1.bcmap","pdfjs/cmaps/Adobe-Japan1-2.bcmap","pdfjs/cmaps/Adobe-Japan1-3.bcmap","pdfjs/cmaps/Adobe-Japan1-4.bcmap","pdfjs/cmaps/Adobe-Japan1-5.bcmap","pdfjs/cmaps/Adobe-Japan1-6.bcmap","pdfjs/cmaps/Adobe-Japan1-UCS2.bcmap","pdfjs/cmaps/Adobe-Korea1-0.bcmap","pdfjs/cmaps/Adobe-Korea1-1.bcmap","pdfjs/cmaps/Adobe-Korea1-2.bcmap","pdfjs/cmaps/Adobe-Korea1-UCS2.bcmap","pdfjs/cmaps/B5-H.bcmap","pdfjs/cmaps/B5-V.bcmap","pdfjs/cmaps/B5pc-H.bcmap","pdfjs/cmaps/B5pc-V.bcmap","pdfjs/cmaps/CNS-EUC-H.bcmap","pdfjs/cmaps/CNS-EUC-V.bcmap","pdfjs/cmaps/CNS1-H.bcmap","pdfjs/cmaps/CNS1-V.bcmap","pdfjs/cmaps/CNS2-H.bcmap","pdfjs/cmaps/CNS2-V.bcmap","pdfjs/cmaps/ETHK-B5-H.bcmap","pdfjs/cmaps/ETHK-B5-V.bcmap","pdfjs/cmaps/ETen-B5-H.bcmap","pdfjs/cmaps/ETen-B5-V.bcmap","pdfjs/cmaps/ETenms-B5-H.bcmap","pdfjs/cmaps/ETenms-B5-V.bcmap","pdfjs/cmaps/EUC-H.bcmap","pdfjs/cmaps/EUC-V.bcmap","pdfjs/cmaps/Ext-H.bcmap","pdfjs/cmaps/Ext-RKSJ-H.bcmap","pdfjs/cmaps/Ext-RKSJ-V.bcmap","pdfjs/cmaps/Ext-V.bcmap","pdfjs/cmaps/GB-EUC-H.bcmap","pdfjs/cmaps/GB-EUC-V.bcmap","pdfjs/cmaps/GB-H.bcmap","pdfjs/cmaps/GB-V.bcmap","pdfjs/cmaps/GBK-EUC-H.bcmap","pdfjs/cmaps/GBK-EUC-V.bcmap","pdfjs/cmaps/GBK2K-H.bcmap","pdfjs/cmaps/GBK2K-V.bcmap","pdfjs/cmaps/GBKp-EUC-H.bcmap","pdfjs/cmaps/GBKp-EUC-V.bcmap","pdfjs/cmaps/GBT-EUC-H.bcmap","pdfjs/cmaps/GBT-EUC-V.bcmap","pdfjs/cmaps/GBT-H.bcmap","pdfjs/cmaps/GBT-V.bcmap","pdfjs/cmaps/GBTpc-EUC-H.bcmap","pdfjs/cmaps/GBTpc-EUC-V.bcmap","pdfjs/cmaps/GBpc-EUC-H.bcmap","pdfjs/cmaps/GBpc-EUC-V.bcmap","pdfjs/cmaps/H.bcmap","pdfjs/cmaps/HKdla-B5-H.bcmap","pdfjs/cmaps/HKdla-B5-V.bcmap","pdfjs/cmaps/HKdlb-B5-H.bcmap","pdfjs/cmaps/HKdlb-B5-V.bcmap","pdfjs/cmaps/HKgccs-B5-H.bcmap","pdfjs/cmaps/HKgccs-B5-V.bcmap","pdfjs/cmaps/HKm314-B5-H.bcmap","pdfjs/cmaps/HKm314-B5-V.bcmap","pdfjs/cmaps/HKm471-B5-H.bcmap","pdfjs/cmaps/HKm471-B5-V.bcmap","pdfjs/cmaps/HKscs-B5-H.bcmap","pdfjs/cmaps/HKscs-B5-V.bcmap","pdfjs/cmaps/Hankaku.bcmap","pdfjs/cmaps/Hiragana.bcmap","pdfjs/cmaps/KSC-EUC-H.bcmap","pdfjs/cmaps/KSC-EUC-V.bcmap","pdfjs/cmaps/KSC-H.bcmap","pdfjs/cmaps/KSC-Johab-H.bcmap","pdfjs/cmaps/KSC-Johab-V.bcmap","pdfjs/cmaps/KSC-V.bcmap","pdfjs/cmaps/KSCms-UHC-H.bcmap","pdfjs/cmaps/KSCms-UHC-HW-H.bcmap","pdfjs/cmaps/KSCms-UHC-HW-V.bcmap","pdfjs/cmaps/KSCms-UHC-V.bcmap","pdfjs/cmaps/KSCpc-EUC-H.bcmap","pdfjs/cmaps/KSCpc-EUC-V.bcmap","pdfjs/cmaps/Katakana.bcmap","pdfjs/cmaps/LICENSE","pdfjs/cmaps/NWP-H.bcmap","pdfjs/cmaps/NWP-V.bcmap","pdfjs/cmaps/RKSJ-H.bcmap","pdfjs/cmaps/RKSJ-V.bcmap","pdfjs/cmaps/Roman.bcmap","pdfjs/cmaps/UniCNS-UCS2-H.bcmap","pdfjs/cmaps/UniCNS-UCS2-V.bcmap","pdfjs/cmaps/UniCNS-UTF16-H.bcmap","pdfjs/cmaps/UniCNS-UTF16-V.bcmap","pdfjs/cmaps/UniCNS-UTF32-H.bcmap","pdfjs/cmaps/UniCNS-UTF32-V.bcmap","pdfjs/cmaps/UniCNS-UTF8-H.bcmap","pdfjs/cmaps/UniCNS-UTF8-V.bcmap","pdfjs/cmaps/UniGB-UCS2-H.bcmap","pdfjs/cmaps/UniGB-UCS2-V.bcmap","pdfjs/cmaps/UniGB-UTF16-H.bcmap","pdfjs/cmaps/UniGB-UTF16-V.bcmap","pdfjs/cmaps/UniGB-UTF32-H.bcmap","pdfjs/cmaps/UniGB-UTF32-V.bcmap","pdfjs/cmaps/UniGB-UTF8-H.bcmap","pdfjs/cmaps/UniGB-UTF8-V.bcmap","pdfjs/cmaps/UniJIS-UCS2-H.bcmap","pdfjs/cmaps/UniJIS-UCS2-HW-H.bcmap","pdfjs/cmaps/UniJIS-UCS2-HW-V.bcmap","pdfjs/cmaps/UniJIS-UCS2-V.bcmap","pdfjs/cmaps/UniJIS-UTF16-H.bcmap","pdfjs/cmaps/UniJIS-UTF16-V.bcmap","pdfjs/cmaps/UniJIS-UTF32-H.bcmap","pdfjs/cmaps/UniJIS-UTF32-V.bcmap","pdfjs/cmaps/UniJIS-UTF8-H.bcmap","pdfjs/cmaps/UniJIS-UTF8-V.bcmap","pdfjs/cmaps/UniJIS2004-UTF16-H.bcmap","pdfjs/cmaps/UniJIS2004-UTF16-V.bcmap","pdfjs/cmaps/UniJIS2004-UTF32-H.bcmap","pdfjs/cmaps/UniJIS2004-UTF32-V.bcmap","pdfjs/cmaps/UniJIS2004-UTF8-H.bcmap","pdfjs/cmaps/UniJIS2004-UTF8-V.bcmap","pdfjs/cmaps/UniJISPro-UCS2-HW-V.bcmap","pdfjs/cmaps/UniJISPro-UCS2-V.bcmap","pdfjs/cmaps/UniJISPro-UTF8-V.bcmap","pdfjs/cmaps/UniJISX0213-UTF32-H.bcmap","pdfjs/cmaps/UniJISX0213-UTF32-V.bcmap","pdfjs/cmaps/UniJISX02132004-UTF32-H.bcmap","pdfjs/cmaps/UniJISX02132004-UTF32-V.bcmap","pdfjs/cmaps/UniKS-UCS2-H.bcmap","pdfjs/cmaps/UniKS-UCS2-V.bcmap","pdfjs/cmaps/UniKS-UTF16-H.bcmap","pdfjs/cmaps/UniKS-UTF16-V.bcmap","pdfjs/cmaps/UniKS-UTF32-H.bcmap","pdfjs/cmaps/UniKS-UTF32-V.bcmap","pdfjs/cmaps/UniKS-UTF8-H.bcmap","pdfjs/cmaps/UniKS-UTF8-V.bcmap","pdfjs/cmaps/V.bcmap","pdfjs/cmaps/WP-Symbol.bcmap","pdfjs/pdf.worker.min.mjs","pdfjs/standard_fonts/FoxitDingbats.pfb","pdfjs/standard_fonts/FoxitFixed.pfb","pdfjs/standard_fonts/FoxitFixedBold.pfb","pdfjs/standard_fonts/FoxitFixedBoldItalic.pfb","pdfjs/standard_fonts/FoxitFixedItalic.pfb","pdfjs/standard_fonts/FoxitSerif.pfb","pdfjs/standard_fonts/FoxitSerifBold.pfb","pdfjs/standard_fonts/FoxitSerifBoldItalic.pfb","pdfjs/standard_fonts/FoxitSerifItalic.pfb","pdfjs/standard_fonts/FoxitSymbol.pfb","pdfjs/standard_fonts/LICENSE_FOXIT","pdfjs/standard_fonts/LICENSE_LIBERATION","pdfjs/standard_fonts/LiberationSans-Bold.ttf","pdfjs/standard_fonts/LiberationSans-BoldItalic.ttf","pdfjs/standard_fonts/LiberationSans-Italic.ttf","pdfjs/standard_fonts/LiberationSans-Regular.ttf"];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((c) => c.addAll(PRECACHE.map((u) => new Request(u, { cache: 'reload' }))))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith('kashikin-') && k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // 外部サイトは扱わない

  if (req.mode === 'navigate') {
    event.respondWith(fetch(req).catch(() => caches.match('./index.html', { ignoreSearch: true })));
    return;
  }

  if (url.pathname.includes('/data/') && url.pathname.endsWith('.json')) {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          if (res.ok) caches.open(CACHE).then((c) => c.put(req, copy));
          return res;
        })
        .catch(() => caches.match(req, { ignoreSearch: true })),
    );
    return;
  }

  event.respondWith(caches.match(req, { ignoreSearch: true }).then((hit) => hit || fetch(req)));
});
